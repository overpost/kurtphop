var d = new Date();
var day=new Array("","","",
"","","","");
var month=new Array("января","февраля","марта","апреля","мая","июня",
"июля","августа","сентября","октября","ноября","декабря");
document.write(day[d.getDay()]+" " +d.getDate()+ " " + month[d.getMonth()]
+ " " );
