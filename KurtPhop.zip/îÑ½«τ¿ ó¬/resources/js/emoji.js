(function(){

var emoji = window.emoji = {};
emoji.replace = Replace;

var GROUPS =
  [
   [/(\ud83c[\udde8-\uddfa])(\ud83c[\udde7-\uddfa])/g, ReplaceFlags],     
   [/[\u0023-\u0039]\u20E3/g,                          ReplaceNumbers],   
   [/[\u2139-\u3299]/g,                                ReplaceStandard],  
   [/[\u203C\u2049]/g,                                 ReplaceStandard],  
   [/([\ud800-\udbff])([\udc00-\udfff])/g,             ReplaceSurrogate]  
  ];

function Replace (source)
  {
   var pattern;
   
   for(var i=0, j=GROUPS.length; i<j; i++)
     {
      pattern = GROUPS[i];
      if(pattern && pattern[0] && pattern[1])
        {
         if(source.match(pattern[0]))
           {
            source = source.replace(pattern[0], pattern[1]);
           }
        }
     }
  
   return(source);
  }
function ReplaceFlags (match)
  {
   return(GetHtmlCodeFromHex(
     [
      GetHexFromSurrogatePair(match.charCodeAt(0), match.charCodeAt(1)).toString(16),
      GetHexFromSurrogatePair(match.charCodeAt(2), match.charCodeAt(3)).toString(16)
     ].join('')));
  }
function ReplaceNumbers (match)
  {
   return(GetHtmlCodeFromHex(match.charCodeAt(0).toString(16) + match.charCodeAt(1).toString(16)));
  }
function ReplaceStandard (match)
  {
   return(GetHtmlCodeFromHex(match.charCodeAt(0).toString(16)));
  }
function ReplaceSurrogate (match, p1, p2)
  {
   return(GetHtmlCodeFromHex(GetHexFromSurrogatePair(p1.charCodeAt(0),p2.charCodeAt(0)).toString(16)));
  }
function GetHexFromSurrogatePair (a, b)
  {
   return((a - 0xD800) * 0x400 + (b - 0xDC00) + 0x10000);
  } 
function GetHtmlCodeFromHex (hex)
  {
   return(['<span class="emojic"><span class="emoji emoji', hex, '"></span><span class="emojit">&#x', hex, ';</span></span>'].join(''));
  }
})();