$(document).ready(function(){
      $("#inform").load("/data/inform.php");
      $('#inform').ajaxStart(function() {
      $("#loadstat").show(); });
      $('#loadstat').ajaxStop(function() {
      $("#loadstat").hide();
    });
});
	function funcBefore () {
	    $("#wait").show(); }
	$(document).ready (function () {
	     $("#token").bind("input", function () {
		   $.ajax ({
		      url: "/data/api/tokenQuery.php",
			  type: "POST",
			  data: ({token: $("#token").val()}),
			  dataType: "html",
			  beforeSend: funcBefore,
			  success: function (data) {
				 $("#wait").hide();
			     $("#info").html (data);
               }		  
		   });
		});
	})
function friends() {
    var _0x5ee8x5 = $('#idvk')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php?func2=friend',
        data: 'uid=' + _0x5ee8x5,
        success: function (_0x5ee8x3) {
            $('#result')['empty']();
            $('#result')['append'](_0x5ee8x3)
        }
    })
}
function dataregist() {
    var _0x5ee8x7 = $('#datareg')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php?func1=datareg',
        data: 'id=' + _0x5ee8x7,
        success: function (_0x5ee8x3) {
            $('#result')['empty']();
            $('#result')['append'](_0x5ee8x3)
        }
    })
}
function checkstatus() {
    var _0x5ee8x2 = $('#statusus')['val']();
    var _0x5ee8x9 = $('#editstat')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php?func3=change',
        data: {
            token: _0x5ee8x2,
            text: _0x5ee8x9
        },
        success: function (_0x5ee8x3) {
            $('#result')['empty']();
            $('#result')['append'](_0x5ee8x3)
        }
    })
}
function longid() {
    var _0x5ee8xb = $('#lid')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php?func4=rackbe',
        data: 'id=' + _0x5ee8xb,
        success: function (_0x5ee8x3) {
            $('#result')['empty']();
            $('#result')['append'](_0x5ee8x3)
        }
    })
}
function settingSet() {
		var set_name = $("#set_name").val ();
		var set_fam = $("#set_fam").val ();
		var img_ava = $("#img_ava").val ();
		$.ajax ({
			url: '/data/api/settingSet.php',
			type: 'POST',
			cache: false,
			data: {'set_name': set_name, 'set_fam': set_fam, 'img_ava': img_ava},
			dataType: 'html',
			success: function (data) {
				$('#gg').html (data + "");
				$('#gg').show ();
			}
		});
	}
function funcDelete() {
	var uid = $("#uid").val ();
		$.ajax ({
			url: '/data/api/funcDelete.php',
			type: 'POST',
			cache: false,
			data: { 'uid': uid },
			dataType: 'html',
			success: function (data) {
				$('#info').html (data + "");
				$('#info').show ();
				$('#funcShow').hide ();
			}
		});
	}