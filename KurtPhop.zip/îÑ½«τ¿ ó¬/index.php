<?
     include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
     $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
     $name = $site['Name'];
     $title = ''.$name.' • Главная';
	 $menu['home'] = 'active';
	 $span['home'] = 'selected';
	 include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>
<div class="col-md-12 animated fadeIn">
<div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
<div class="portlet-body"><div class="form-body">
<img style="float:left; wight:120px; height:120px;" src="/resources/img_site/support.gif">
<div class="row"><center>
<div class="col-md-10"><h4>Техническая поддержка сайта 24/7 ТИГР <img src="https://vk.com/images/emoji/26A0.png"></h4>
<h5>Приветствуем тебя на нашем сервисе. Желаем вам приятно провести время <img src="https://vk.com/images/emoji/D83DDE09.png"></h5>
<h5>Если у вас возникнут вопросы, то вы можете зайти в раздел "<a href="/pages/help.php">Помощь</a>" <img src="https://vk.com/images/emoji/D83DDE07.png"></h5> <div></div></div>
</center></div></div></div></div></div>
<div class="col-md-12">
<div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="icon-bar-chart font-dark hide"></i><span class="caption-subject font-dark bold uppercase">О Сайте</span></div></div><div class="portlet-body">
<ul class="list-group"><li class="list-group-item"><center>Приветствуем в нашем сервисе <li class="badge badge-danger">KurtPhop.PW</li></center></li>
<li class="list-group-item"><center>Наш сайт использует только официально предоставленные социальными сетями возможности для разработчиков.</li></center>
<li class="list-group-item"><center>А так же сможете скачать <li class="label label-info">php</li> скрипты, установить себе на страницу <li class="label label-info">«Авто-статус»</li>или же<li class="label label-info">«В онлайн»</li> и многое другое.</center></li>
</ul></div></div>
</div><div id="inform"><div id="loadstat"><center><div class="panel-heading summary-head"><img src="/resources/img_site/loading-spinner-blue.gif" /></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>