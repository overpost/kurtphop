<?
$menu['help'] = 'active';
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Помощь';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-md-12 col-sm-12">
<div class="portlet light "><div class="portlet-title tabbable-line"><div class="caption"><i class="icon-bubbles font-dark hide"></i><span class="caption-subject font-dark bold uppercase">Помощь по сайту</span></div>
<ul class="nav nav-tabs"><li class="active"><a href="#portlet_tab2_1" data-toggle="tab" aria-expanded="true"> Ответы на некоторые вопросы </a></li>
<li class=""><a href="#portlet_tab2_2" data-toggle="tab" aria-expanded="false"> Задать вопрос агенту поддержки </a></li></ul></div>
<div class="portlet-body"><div class="tab-content"><div class="tab-pane active" id="portlet_tab2_1"><div class="panel-group accordion" id="accordion1"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_1" aria-expanded="false">1. Что такое токен? </a></h4></div>
<div id="collapse_1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
<div class="panel-body">Это часть ссылки от <span class="label label-primary">access_token=</span> до <span class="label label-primary">&amp; </span>										</div></div></div>
<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_2" aria-expanded="false">2. Где взять токен? </a></h4></div>
<div id="collapse_2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
<div class="panel-body">Получить токен можно по этой <button type="button" class="btn btn-primary btn-xs" onclick="window.open('http://vk.cc/2r7WXp');return false;">ссылке</button>										</div></div></div>																		
<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">
<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_3" aria-expanded="false"> 3. У меня не рабочий токен, что делать? </a>
</h4></div><div id="collapse_3" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;"><div class="panel-body">Зайдите <button type="button" class="btn btn-info btn-xs" onclick="window.open('https://vk.com/apps?act=settings');return false;">сюда</button> и удалите все приложения, после этого получите токен.
</div></div></div>
<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_4" aria-expanded="false">4. Что дают привилегии?</a></h4></div>
<div id="collapse_4" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
<div class="panel-body"> 1.Верификация - Галочка не чего не дает.Если у пользователя есть галочка это не значит что ему ее выдали. Он мог ее купить в магазине.
<br>
2.  Инкогнито - Ваш профиль не кто не сможет посмотреть.</div></div></div>
</div></div><div class="tab-pane" id="portlet_tab2_2">
<div class="portlet-body"><div class="btn-group btn-group-circle btn-group btn-group-justified">
<a href="https://vk.com/mr.kurtphop" class="btn red">Агент Поддержки #1</a>
<a href="https://vk.com/egidarov" class="btn green">Агент Поддержки #2</a>
</div></div></div></div></div></div></div>

<? include($_SERVER['DOCUMENT_ROOT'] . '/data/foot.php'); ?>