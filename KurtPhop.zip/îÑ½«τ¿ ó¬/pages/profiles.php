<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if (isset($_GET['id'])) {

/* Ну тут мы типа делаем вывод в титл Имя и Фамилию */

$getid = $_GET['id'];
$wh = $mysqli->query('SELECT * FROM `users` WHERE id="'.$getid.'"');
if(mysqli_num_rows($wh) == 0) {
}else{
while($gg = $wh->fetch_array()){
$first_name = $gg['first_name'];
$last_name = $gg['last_name']; }

    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
	$title = ''.$name.' • '.$first_name.' '.$last_name.''; }
/* Ну а тут страдаем хернёй и достаём из бд всю инфу о челе */

include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); 
$getid = $_GET['id'];
$info = $mysqli->query('SELECT * FROM `users` WHERE id="'.$getid.'"'); 
while($row = $info->fetch_array()) {
$id = $row['id'];
$first_name = $row['first_name'];
$last_name = $row['last_name'];
$photo = $row['photo'];
$ban = $row['ban'];
$admin = $row['admin'];
$datereg = $row['datereg'];
$lastjoin = $row['lastjoin'];
$profile = $row['profile'];
$money = $row['money'];
$token = $row['token'];
$hidden = $row['hidden'];
$verify = $row['verify'];
$slg = $row['slg']; } }

if($ban == 2){
$statusUser = "<span class='text-danger'>Banned by AAC</span>";
}else{ 
if($admin == 2){
$statusUser = '<a class="popovers" data-container="body" data-trigger="hover" data-placement="right" data-content="У пользователя '.$first_name.' '.$last_name.' установлен префикс. Привилегия аккаунта: Разработчик" data-original-title="Информация">
<span class="text-info">Администратор</span>
</a>';
}else{
$statusUser = "Пользователь";
}}

if($ban == 2){
$ver = "";
}else{
if($verify == 2){
$ver = '<a class="popovers" data-container="body" data-trigger="hover" data-placement="right" data-content="Данная отметка означает, что страница была подтверждена администрацией сайта." data-original-title="Подтверждённая страница"><img src="/resources/img_site/verify.png" alt=""><span class="page_verified"></span>
</a>';
}else{ 
$ver = "";
}}

if($ban == 2){
$bylike = '<div class="profile-userbuttons">
<input type="hidden" id="Likes_id" name="Likes_id" value="7">
<div id="Likes"></div>';
} else { 
$getLikes = curl('https://api.vk.com/method/photos.get?album_id=profile&rev=1&extended=1&count=1&uid='.$profile);
$getLikesJson = json_decode($getLikes,1);
$likes = $getLikesJson['response']['0']['likes']['count'];

$bylike = '
<div class="profile-userbuttons">
<input type="hidden" id="Likes_id" name="Likes_id" value="7">
<div id="Likes">
<button type="button" class="btn btn-circle green-haze btn-sm"><i class="fa fa-thumbs-o-up"> '.$likes.' </i></button>
</div>'; }

$uget = curl('https://api.vk.com/method/users.get?name_case=Nom&fields=status&uid='.$profile);                  
$json = json_decode($uget,1); $stat = $json['response']['0']['status'];
if($stat == '') {} else { $status = '<div class="col-md-12"><li class="list-group-item bg-green"> '.$stat.' </li><br></div>'; }

$d = time() - strtotime($lastjoin);
if ($d < 60) $stamp = $d . ' сек. назад';
elseif ($d < 3600) $stamp = round($d / 60) . ' мин. назад';
elseif ($d < 86400) $stamp = round($d / 3600) . ' ч. назад';
else $stamp = round($d / 86400) . ' дн. назад';

$result = $mysqli->query('SELECT `online` FROM `users` WHERE `id`="'.$_GET['id'].'"');
$rof = $result->fetch_array();
$onl = $rof['online'];
if($onl == 2) {
$onlinestatus = '<span class="fa fa-circle text-success" value="Online"></span>';
}else { $onlinestatus = '<span class="fa fa-circle text-danger" value="Offline"></span>'; }

$check = $mysqli->query('SELECT * FROM `users` WHERE id="'.$getid.'"'); 

$result = $mysqli->query('SELECT `online` FROM `users` WHERE `id`="'.$_GET['id'].'"');
$rof = $result->fetch_array();
$onl = $rof['online'];
if($onl == 2) {
$stampTrue = 'Онлайн';
}else { $stampTrue = 'Последний вход '.$stamp.''; }

if(mysqli_num_rows($check) == 0) { ?>
<link href="/resources/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="/assets/css/profile.css" rel="stylesheet" type="text/css">
<div class="col-md-3">
<div class="portlet light profile-sidebar-portlet">
<div class="profile-userpic">
<div id="ava"><img src="/resources/img_site/deactivated_200.png" style="width:40%" class="img-responsive" alt=""></div>
<input type="hidden" id="id_upd" name="id_upd" value="">
</div>
<div class="profile-userbuttons">
<input type="hidden" id="Likes_id" name="Likes_id" value="1">
<div id="Likes">
</div>
</div>
<div class="profile-usermenu">
<ul class="nav">
<li class="active">
<a data-toggle="tab" href="#tab_1-1" aria-expanded="true">
<i class="icon-info"></i>Информация </a></li>
</ul>
</div>
</div>
</div>
<div class="col-md-9">
<div class="portlet box green"><div class="portlet-title">
<div class="caption"><i class="fa fa-warning"></i><span class="caption">Информация</span></div></div>
<div class="portlet-body"><div class="form-body">
<div class="tab-content">
<div id="infos" class="tab-pane active">
<ul class="list-group"><li class="list-group-item bg-blue"><center>Пользователь не найден</center></li></ul></div></div></div></div></div>
<? }else{ ?>

<link href="/assets/css/profile.css" rel="stylesheet" type="text/css">
<? echo $status; ?>
<div id="resultd"></div>
<div class="col-md-3">
<div class="portlet light profile-sidebar-portlet">
<div class="profile-userpic">
<div id="ava"><img src="<? echo "$photo"; ?>" style="width: 40%;" class="img-responsive" alt=""></div>
<input type="hidden" id="id_upd" name="id_upd" value="">
</div>
<div class="profile-usertitle">
<div class="profile-usertitle-name"> <? echo "$first_name $last_name"; ?>  <? echo $onlinestatus; ?> </div>
<div class="profile-usertitle-job"> <? echo "$statusUser"; ?> <? echo "$ver"; ?> </div> 
</div>
<? echo $bylike; ?>
</div>
<div class="profile-usermenu">
<ul class="nav">
<li class="active">
<a data-toggle="tab" href="#infos" aria-expanded="true">
<i class="icon-info"></i> Информация </a></li>
<? session_start();
if (isset($_SESSION['uid'])) {
$ul1 = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($niceHax = $ul1->fetch_array()) {
$xzId = $niceHax['id']; }
if ($_GET['id'] == $xzId) { ?>
<li class=""><a data-toggle="tab" href="#settings" aria-expanded="false"><i class="icon-settings"></i>Настройки</a></li>
<li class=""><a data-toggle="tab" href="#func" aria-expanded="false"><i class="icon-drawer"></i>Функции</a></li>
<? } } ?>
<br>
</ul>
</div>
</div>
</div>

<div class="col-md-9">
<div class="portlet box green"><div class="portlet-title">
<div class="caption"><i class="fa fa-info"></i><span class="caption">Информация</span></div></div>
<div class="portlet-body"><div class="form-body">
<div class="tab-content">
<? if($ban == 2){
echo '<div class="portlet-body"><ul class="list-group"><li class="list-group-item bg-red"><center>Профиль заблокирован системой AAC. Просмотр профиля не доступен</center></li></ul></div>';
}else{?>
<? session_start();
$sql1 = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row1 = $sql1->fetch_array()) {
$did = $row1['id'];
}
if ($_GET['id'] == $did) { ?>
<div id="infos" class="tab-pane active">
<table class="table about-table">
<tr><th>Дата регистрации</th><td><span class="badge badge-danger"><? echo "$datereg"; ?></span></td></tr>
<tr><th>Баланс</th><td><span class="badge badge-success"><? echo "$money"; ?></span></td></tr>
<tr><th>Страница Вконтакте</th><td><a href="http://vk.com/id<? echo "$profile"; ?>"><span class="badge badge-warning">Профиль</span></a></td></tr>
<tr><th>Статус</th><td><span class="badge badge-info"><? echo $stampTrue ?></span></td></tr>
</table>
</div>
<div id="settings" class="tab-pane">

<div id="gg"></div>
<li class="list-group-item">Имя</li>
<li class="list-group-item"><div class="form-group"><input type="text" name="set_name" id="set_name" value="<? echo $first_name; ?>" class="form-control"></div></li>
<li class="list-group-item">Фамилия</li>
<li class="list-group-item"><div class="form-group"><input type="text" name="set_fam" id="set_fam" value="<? echo $last_name; ?>" class="form-control"></div></li>
<li class="list-group-item">Аватарка</li><li class="list-group-item"><div class="form-group"><div class="fileinput-new thumbnail"><img src="<? echo $photo; ?>" style="wight: 150px; height: 150px" alt=""></div>
<input type="text" name="img_ava" id="img_ava" value="<? echo $photo; ?>" class="form-control">
</div>
</li>
<li class="list-group-item">
<center><button class="btn btn-minw btn-square btn-primary btn-circle" onclick="settingSet()">Сохранить</button></center>
</li>
</div>
<div id="func" class="tab-pane">
<div id="info"></div>
<li class="list-group-item bg-red">Здесь приведены установленные скрипты</li><br>
<li class="list-group-item">
Для редактирования параметров скриптов введите в эти поля ACCESS_TOKEN
</li>
<li class="list-group-item">
<center>
<button type="button" class="btn btn-minw btn-square btn-success" onclick="window.open('https://oauth.vk.com/authorize?client_id=2890984&amp;scope=notify,friends,photos,audio,video,docs,notes,messages,pages,status,wall,groups,notifications,stats,questions,offers,offline&amp;redirect_uri=blank.html&amp;display=popup&amp;response_type=token')">Токен с телефона</button>
<button type="button" class="btn btn-minw btn-square btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=4187848&amp;redirect_uri=http://api.vk.com/blank.html&amp;scope=offline&amp;display=page&amp;response_type=token')">Токен с компьютера</button>
</center>
</li>
<li class="list-group-item">
<div class="input-group">
<span class="input-group-addon">ACCESS_TOKEN:</span>
<input type="text" name="token_vk" id="token_vk" class="form-control" placeholder="ACCESS_TOKEN">
</div>
</li>
<br>
<div id="func_res">
<? $go1 = $mysqli->query('SELECT * FROM `status` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if(mysqli_num_rows($go1) == 0) { } else {
$stat = $go1->fetch_array();
	$statid = $stat['status_id'];
	$statcity = $stat['city'];
	$stattoken = $stat['token'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success"><i class="fa fa-check-circle"></i> В активном состоянии</div>';
	$redakt = ''; }else{
		$statusValide = '<div class="text-danger"><i class="fa fa-ban"></i> Токен невалидный</div>'; 
        $redakt = '<a class="btn blue">Редактировать</a>'; }
/* Конец проверки */
echo '
<div class="portlet box green"><div class="portlet-title"><div class="caption">АвтоСтатус #'.$statid.'</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr>			
<td class="web-inspector-hide-shortcut"><center><img src="/resources/img_site/status/status-'.$statid.'.png"></center></td></tr><tr>			
<td class="web-inspector-hide-shortcut"><center>'.$statusValide.'</center></td>
</tr><td><div class="btn-group-justified">'.$redakt.'<a id="killStatus" class="btn red">Удалить</a></div></td><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div></div></div>';  }

/* ААААА СЛОЖНА */

$go2 = $mysqli->query('SELECT * FROM `groupstat` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if(mysqli_num_rows($go2) == 0) { } else {
$groupstat = $go2->fetch_array();
	$stattoken = $groupstat['token'];
	$group = $groupstat['group'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success"><i class="fa fa-check-circle"></i> В активном состоянии | Группа: '.$group.'</div>';
	$redakt = ''; }else{
		$statusValide = '<div class="text-danger"><i class="fa fa-ban"></i> Токен невалидный</div>'; 
        $redakt = '<a class="btn blue">Редактировать</a>'; }
		
/* Конец проверки */
echo '
<div class="portlet box yellow"><div class="portlet-title"><div class="caption">АвтоСтатус в Группу</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr>			
<td class="web-inspector-hide-shortcut"><center><img src="/resources/img_site/groupstat.png"></center></td></tr><tr>			
<td class="web-inspector-hide-shortcut"><center>'.$statusValide.'</center></td>
</tr><td><div class="btn-group-justified">'.$redakt.'<a id="killGroup" class="btn red">Удалить</a></div></td><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div></div></div>';  }

/* ВЕЧНЫЙ АНЛАИН((( */

$go3 = $mysqli->query('SELECT * FROM `online` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if(mysqli_num_rows($go3) == 0) { } else {
$onlinestat = $go3->fetch_array();
	$stattoken = $onlinestat['token'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success"><i class="fa fa-check-circle"></i> В активном состоянии</div>';
	$redakt = ''; }else{
		$statusValide = '<div class="text-danger"><i class="fa fa-ban"></i> Токен невалидный</div>'; 
        $redakt = '<a class="btn blue">Редактировать</a>'; }
/* Конец проверки */
echo '
<div class="portlet box purple"><div class="portlet-title"><div class="caption">Вечный онлайн</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr></tr><tr>			
<td class="web-inspector-hide-shortcut"><center>'.$statusValide.'</center></td>
</tr><td><div class="btn-group-justified">'.$redakt.'<a id="killOnline" class="btn red">Удалить</a></div></td><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div></div></div>';  }

/* ФУНКЦИИ:D */

$go4 = $mysqli->query('SELECT * FROM `set_func` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if(mysqli_num_rows($go4) == 0) { } else {
$funcstat = $go4->fetch_array();
	$stattoken = $funcstat['token'];
	$friends_add = $funcstat['friends_add'];
	$friends_delete = $funcstat['friends_delete'];
	$online = $funcstat['online'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
		
if($friends_add == 2){
	$friends_add1 = '<td class="list-group-item"><center><div class="text-info">Автодобавление в друзья: Включено</div></center></td>';
} else { $friends_add1 = '<td class="list-group-item"><center><div class="text-danger">Автодобавление в друзья: Выключено </div></center></td>'; }
if($friends_delete == 2){
	$friends_delete1 = '<td class="list-group-item"><center><div class="text-info">Автоудаление из подписок: Включено</div></center></td>';
} else { $friends_delete1 = '<td class="list-group-item"><center><div class="text-danger">Автоудаление из подписок: Выключено </div></center></td>'; }
if($online == 2){
	$online1 = '<td class="list-group-item"><center><div class="text-info">Вечный онлайн: Включен </div></center></td>';
} else { $online1 = '<td class="list-group-item"><center><div class="text-danger">Вечный онлайн: Выключен </div></center></td>'; }
	$statusValide = '<div class="text-success"><i class="fa fa-check-circle"></i> В активном состоянии</div>';
	$redakt = ''; }else{ $statusValide = '<div class="text-danger"><i class="fa fa-ban"></i> Токен невалидный</div>'; 
    $redakt = '<a class="btn blue">Редактировать</a>'; }
/* Конец проверки */
echo '
<div id="funcShow" class="portlet box green"><div class="portlet-title"><div class="caption">Функции</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr></tr><tr>
'.$friends_add1.' '.$friends_delete1.' '.$online1.'
<li class="list-group-item"><center>'.$statusValide.'</center></li>
</tr><td><div class="btn-group-justified">'.$redakt.'<a id="funcDelete();" class="btn red">Удалить</a></div></td><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div></div></div>';  } ?>
</div>
</div>
<? } else {
$sql = $mysqli->query('SELECT `hidden` FROM `users` WHERE `profile` = "'.$_GET['id'].'"');
while($row = $sql->fetch_array()) { $hidden = $row['hidden']; } if($hidden == 2){ ?>
<div class="portlet-body"><ul class="list-group"><li class="list-group-item bg-blue"><center>Профиль скрыт</center></li></ul></div><style>.mlg-snoop-dogg {position: fixed;bottom: 0;  right: 0;}</style>
<style>.awp {position: fixed;bottom: 0;  center: 0;}</style>
<? if($slg == 2){ ?><img src="http://i0.kym-cdn.com/photos/images/original/000/858/365/853.gif" alt="mlg snoop dogg" width="20%" class="mlg-snoop-dogg"><? } else ?>
<? }else{ ?>
<div id="infos" class="tab-pane active">
<table class="table about-table">
<tbody>
<tr><th>Дата регистрации</th><td><span class="badge badge-danger"><? echo "$datereg"; ?></span></td></tr>
<tr><th>Баланс</th><td><span class="badge badge-success"><? echo "$money"; ?></span></td></tr>
<tr><th>Страница Вконтакте</th><td><a href="http://vk.com/id<? echo "$profile"; ?>"><span class="badge badge-warning">Профиль</span></a></td></tr>
<tr><th>Статус</th><td><span class="badge badge-info"><? echo $stampTrue ?></span></td></tr>
</tbody>
</table>
</div>
<? } } } } ?>
<?php
function api($method, $parameter) { 
$return = curl("https://api.vk.com/method/" . $method . "?" . $parameter);
return json_decode($return, true); 
}
function curl($url, $post = null) {
$ch = curl_init( $url );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417
Firefox/3.0.3');
if	($post) {
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
?>
</div>
</div>
</div>
</div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>