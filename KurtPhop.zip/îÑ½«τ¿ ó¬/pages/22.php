<?
$menu['help'] = 'active';
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Статус в группу';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); 
$s2 = $mysqli->query("SELECT COUNT(*) as count FROM `groupstat`");
while($db = $s2->fetch_array()) { $groupAvto = $db['0']; }
?>

<div id="info"></div>
<div class="col-md-12 col-sm-12 animated fadeIn">
<div class="portlet light ">
<div class="portlet-title tabbable-line">
<div class="caption">
<i class="icon-bubbles hide"></i>
<span class="caption-subject uppercase">Автостатусы (Всего установило: <? echo $groupAvto ?>)</span></div>
<ul class="nav nav-tabs">
	<li><a aria-expanded="false" href="status_del">Удаление</a></li>
	<li><a aria-expanded="false" href="status_edit">Редактирование</a></li>
</ul>
</div>
<div class="portlet-body">
<div class="portlet light bordered">
						<div class="portlet-title">
							<div class="caption">
								<span class="caption-subject font-cyan-500"> Статус #1<br><small></small> </span>
							</div>
						</div>
					<div class="portlet-body"><center><img src="/resources/img_site/groupstat.png" class="img-responsive"></center><br>
				<center><a type="button" class="btn btn-minw btn-square btn-primary" href="/autoSet/avtostatus_group/setStatus.php">Установить</a></center>
			</div>
		</div></div></div></div> 
<? include($_SERVER['DOCUMENT_ROOT'] . '/data/foot.php'); ?>