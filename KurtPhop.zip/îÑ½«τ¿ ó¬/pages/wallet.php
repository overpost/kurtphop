<?
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Магазин';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<form method="post">
<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
$id = $row['id'];
$money = $row['money'];
$verify = $row['verify'];
$hidden = $row['hidden'];
} } else { break; }

/* 
Проверка
*/

if($hidden == 2){
$hdn = '<button type="button" class="btn blue btn-outline">Включено</button>';
}else{
	$hdn = '<button type="hidden" id="hidden" name="hidden" class="btn btn-danger"> Купить (15) </button>';
}

if($verify == 2){
$ver = '<button type="button" class="btn blue btn-outline">Включено</button>';
}else{
	$ver = '<button type="verify" id="verify" name="verify" class="btn btn-danger"> Купить (40) </button>';
}

/*
Покупка
*/

if (isset($_POST['hidden'])){
if (("$money") >= 15) { 
$total = $money - 15;
$mysqli->query("update users set money = '$total' where id = '$id' ");
echo '<div class="col-md-12" id="status"><li class="list-group-item bg-green"> Спасибо за покупку. Функция активирована </li><br></div>';
$mysqli->query("update users set hidden = '2' where id = '$id' ");
} else { 
echo  '<div class="col-md-12" id="status"><li class="list-group-item bg-green"> У вас недостаточно денег. У вас: '.$money.' </li><br></div>'; }
}

if (isset($_POST['verify'])){
if (("$money") >= 40) {
$total = $money - 40;
$mysqli->query("update users set money = '$total' where id = '$id' ");
echo '<div class="col-md-12" id="status"><li class="list-group-item bg-green"> Спасибо за покупку. Функция активирована </li><br></div>';
$mysqli->query("update users set verify = '2' where id = '$id' ");
} else { 
echo  '<div class="col-md-12" id="status"><li class="list-group-item bg-green"> У вас недостаточно денег. У вас: '.$money.' </li><br></div>'; }
}
?>

<div class="col-md-12">
	<div class="portlet box green">
		<div class="portlet-title">
		<div class="caption">
		<i class="fa fa-credit-card font-blue"></i> <span class="caption-subject font-dark uppercase">Магазин</span></div>
		<div class="actions"><div class="btn-group"><a class="btn btn-default" style="color: #fff">Баланс: <? echo "$money"; ?>  <i class="fa fa-money"></i></a></div>
		</div>
	</div>
	<div class="portlet-body">
		<div class="tab-content">
			<table class="table table-responsive">
                <tbody>
                    <tr>
                        <td> <b class="pull-left"> <i class="fa fa-eye-slash fa-lg fa-fw"></i> Инкогнито </b> </td>
                        <td> Данные о вашей странице не отображаются. <a href="/id1">Пример.</a> </td>
                        <td>  <? echo "$hdn"; ?>  </td>
					</tr>
                    <tr>
                        <td> <b class="pull-left"> <i class="fa fa-check fa-lg fa-fw"></i> Верификация</b> </td>
                        <td> Отметка которая означает, что страница была подтверждена администрацией сайта. </td>
                        <td>  <? echo "$ver"; ?>  </td>
					</tr>
				</tbody>
			</table>			
		</div>
	</div>
</div>
</div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>