<?
$menu['help'] = 'active';
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Помощь проекту';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-md-12 col-sm-12">
<div class="portlet light ">
<div class="portlet-title tabbable-line">

<li class="list-group-item">
								<b>1</b>. Сайт на платным хостинге, оплачивать его каждый раз <b>Администратор</b> не в силах, поэтому, кто сколько сможет, мы будем рады всему.
							</li>
							<li class="list-group-item">
								<b>2</b>. Если надумаете кидать, в <b>примечании</b> вписываем ссылку от Вашего аккаунта ВКонтакте.
							</li>
							<li class="list-group-item">
							<span class="badge badge-warning">
												QIWI
											</span>
											<td>
											+79504172234
										</td>
											</li>
							

</div></div></div>

<? include($_SERVER['DOCUMENT_ROOT'] . '/data/foot.php'); ?>