<?
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Api VK';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>
<div id="info"></div>
<div class="col-md-12">
<div class="portlet box blue">
<div class="portlet-title">
<div class="caption">Чекер токена</div>
</div>
<div class="portlet-body">
<div class="form-body">
<li class="list-group-item"><b>1.</b> Получите свой <b>access_token</b> от приложения</li>
<li class="list-group-item"><center><div id="wait" class="btn default purple-stripe" style="display: none;"><i class="fa fa-spin fa-cog"></i> Загрузка информации </div>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3116505&amp;scope=friends,photos,audio,video,docs,notes,pages,status,offers,questions,wall,groups,messages,notifications,stats,ads,market,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">iPhone</button></center></li>
<li class="list-group-item"><b>2.</b> Введите свой access_token / Проверка автоматическая</li>
<li class="input-group"><input type="text" class="form-control" name="token" id="token" placeholder="Access_Token"><span class="input-group-btn"><input type="hidden" id="apivk" name="apivk" value="del_request"><button class="btn btn-minw btn-square btn-primary">Авто Проверка</button></span></li></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>