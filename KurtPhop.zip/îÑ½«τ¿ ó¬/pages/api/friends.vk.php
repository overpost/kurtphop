<?
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Api VK';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>
<div id="result"></div>
<div class="col-md-12">

<div class="portlet box blue ">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gift"></i> Список друзей </div>
                                    <div class="tools">
                                        <a href="" class="collapse" data-original-title="" title=""> </a>   
 </div> </div>
 <div class="portlet-body form"> <div class="form-body">
 <div class="input-icon"><i class="fa fa-vk font-blue"></i>
 <input type="text" class="form-control" name="idvk" id="idvk" placeholder="Введите ид пользователя">
 </div></div>
 <div class="form-actions">
 <center><button onclick="friends();" class="btn red">Получить список</button>
 </center></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>