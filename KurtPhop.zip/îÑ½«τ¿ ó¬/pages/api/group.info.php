<?
include($_SERVER['DOCUMENT_ROOT'].'/cpanel/head.php');
?>
<div class="col-md-12">
<div class="blog">
									<div class="blog-header">
										<h5 class="blog-title">Узнаём информацию о группе</h5>
									</div>
									<div class="blog-body">

<?php

      if (isset($_POST['uid'])){

      $uid = htmlspecialchars($_POST['uid']);


	$groups_getMembers = api("groups.getMembers", "group_id=" . $uid);
	$count = $groups_getMembers ["response"] ["count"];

	$groups_getById = api("groups.getById", "group_id=" . $uid . "&fields=photo_50,status,verified");
	$name = $groups_getById ["response"] ["0"] ["name"];
	$screen_name = $groups_getById ["response"] ["0"] ["screen_name"];
	$photo_50 = $groups_getById ["response"] ["0"] ["photo_50"];
	$status = $groups_getById ["response"] ["0"] ["status"];
	$type = $groups_getById ["response"] ["0"] ["type"];
	$verified = $groups_getById ["response"] ["0"] ["verified"];

        if($verified == "1"){
        $ver = "Присутствует";
        }
        else{
        $ver = "Отсутствует";
        }


        if($count){

	echo '<hr><div class="result">
							<hr>
								<ul class="recent-posts">
									<li class="post">
										<img src="'.$photo_50.'" style="border-radius:1337px;float:right;margin-right:10px;">
										<div class="details">
											<h5 class="blog-title">'.$name.'</h5>
											Статус: '.$status.'<br>
											Верификация: '.$ver.'<br>
                                            Тип группы: '.$type.'<br>
                                            Домен: vk.com/'.$screen_name.'</div>
										</div>
									</li>
								</ul>
							<hr>
						</div>';

	}else{

	echo '<div class="note note-danger">Такой группы нет</div>';
        }
          }
           ?>
<form method="post">
										<ul class="recent-posts">
											<div class="result"></div>
											<li class="list-group-item">
												<b>1</b>. Введите ID или домен группы.
											</li>
											<li class="input-group">
												<input type="text" name="uid" id="uid" class="form-control" placeholder="ID группы" value="" required="">
												<span class="input-group-btn">
													<button type="submit" class="btn btn-info" id="banned">Отправить</button>
												</span>
											</li>
										</ul>
									</div>
								</div>
<?
                             function api($method, $parameter) { 
		             $return = curl("https://api.vk.com/method/" . $method . "?" . $parameter);
		             return json_decode($return, true); 
                             }
          	function curl($url, $post = null) {
		$ch = curl_init( $url );
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417
		Firefox/3.0.3');
		if	($post) {
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
    }
?>

<?
include($_SERVER['DOCUMENT_ROOT'].'/cpanel/foot.php');
?>