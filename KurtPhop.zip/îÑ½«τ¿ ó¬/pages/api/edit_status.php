<?
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Api VK';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>
<div id="result"></div>
<div class="col-md-12">
<div class="portlet box blue ">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gift"></i> Смена статуса | Проверка капчи. </div>
                                    <div class="tools">
                                        <a href="" class="collapse" data-original-title="" title=""> </a>   
 </div> </div>
 <div class="portlet-body form"> <div class="form-body">
 <div class="input-icon"><i class="fa fa-vk font-blue"></i>
 <input type="text" class="form-control" name="statusus" id="statusus" placeholder="Введите свой access_token в поле">
 </div>
 </br>
  <div class="input-icon"><i class="fa fa-pencil font-green"></i>
 <input type="text" class="form-control" name="editstat" id="editstat" placeholder="Введите текст статуса">
 </div></div>
 <div class="form-actions">
 <center><button onclick="checkstatus();" class="btn red">Проверить/Сменить</button>
 </center></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>