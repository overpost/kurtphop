<?
$menu['help'] = 'active';
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Токен';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-md-12 col-sm-12">
<div class="portlet light ">
<div class="portlet-title tabbable-line">

      <h3 class="project-tagline">Выберите приложение</h3>
  <button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3698024&amp;scope=friends,photos,pages,status,offers,groups,messages,stats,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Instagram</button>
  <button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=2685278&amp;scope=friends,photos,pages,status,offers,groups,messages,stats,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Kate Mobile</button>
  <button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3116505&amp;scope=friends,photos,pages,status,offers,groups,messages,stats,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">VK API</button>
  <button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=2890984&scope=friends,photos,pages,status,offers,groups,messages,stats,offline&redirect_uri=http://api.vk.com/blank.html&display=page&response_type=token')">Android</button>

</div></div></div>

<? include($_SERVER['DOCUMENT_ROOT'] . '/data/foot.php'); ?>