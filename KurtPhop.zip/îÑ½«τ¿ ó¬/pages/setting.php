<? include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>

<? 
$sql = $mysqli->query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
while($row = $sql->fetch_array()) {
$id = $row['id'];
$fname = $row['first_name'];
$lname = $row['last_name'];
$ph = $row['photo'];
$profile = $row['profile']; }

if (isset($_POST['update'])) {
if (isset($_POST['nameUp']) && isset($_POST['lastUp']) && isset($_POST['phUp'])) {
$nameUp = htmlspecialchars($_POST['nameUp']);
$lastUp = htmlspecialchars($_POST['lastUp']);
$phUp = htmlspecialchars($_POST['phUp']);
echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Данные успешно изменнены</li></ul></div>';
$sql = $mysqli->query('UPDATE `users` SET `first_name`="'.$nameUp.'", `last_name`="'.$lastUp.'", `photo`="'.$phUp.'" WHERE `id`="'.$id.'"');
  }
}
if(isset($_POST['updAva'])) {
  $users_get = curl('https://api.vk.com/method/users.get?fields=photo_max&user_ids='.$profile.'');                  
  $json = json_decode($users_get,1);
  $newAva = $json['response']['0']['photo_max'];
  $mysqli->query('UPDATE `users` SET `photo`="'.$newAva.'" WHERE `id`="'.$id.'"');
  
  echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Ваш аватар обновлён</li></ul></div>';
}
?>
<form method="post">
<div class="col-md-12">
<div class="portlet box green">
<div class="portlet-title">
<div class="caption">Редактирование</div>
</div><div class="portlet-body">
<div class="form-group has-success">
<label class="control-label">Имя</label>
<input type="text" value="<? echo "$fname"; ?>" name="nameUp" class="form-control"> </div>
<div class="form-group has-success">
<label class="control-label">Фамилия</label>
<input type="text" value="<? echo "$lname"; ?>" name="lastUp" class="form-control"> </div>
<div class="form-group has-success">
<label class="control-label">Аватарка</label>
<input type="text" value="<? echo "$ph"; ?>" name="phUp" class="form-control"> </div>
<div class="margiv-top-10">
<button class="btn green" type="update" id="update" name="update">Сохранить</button>
<button class="btn blue" type="updAva" id="updAva" name="updAva">Обновить аватар</button>
</div></div></div></div></form>
<?
                             function api($method, $parameter) { 
		             $return = curl("https://api.vk.com/method/" . $method . "?" . $parameter);
		             return json_decode($return, true); 
                             }
          	function curl($url, $post = null) {
		$ch = curl_init( $url );
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417
		Firefox/3.0.3');
		if	($post) {
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
    }
?>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>