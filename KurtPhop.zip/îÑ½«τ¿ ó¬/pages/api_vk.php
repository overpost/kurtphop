<?
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Api VK';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>
<div class="col-md-12">
	<div class="portlet box green">
		<div class="portlet-title">
			<div class="caption">
				API для Вконтакте
			</div>
		</div>
		<div class="portlet-body">
			<div class="form-body">
				<center>
													<a href="/pages/api/access_token.php" class="list-group-item list-group-item-default" data-original-title="" title="">Проверка валидности access_token</a>
													<a href="/pages/api/datareg.php" class="list-group-item list-group-item-default" data-original-title="" title="">Дата регистрации</a>
													<a href="/pages/api/edit_status.php" class="list-group-item list-group-item-default" data-original-title="" title="">Редактирование статуса</a>
													<a href="/pages/api/friends.vk.php" class="list-group-item list-group-item-default" data-original-title="" title="">Список друзей по ид</a>
													<a href="/pages/api/longid.php" class="list-group-item list-group-item-default" data-original-title="" title="">Длинный ид пользователя</a>
												</center>
			</div>				
		</div>
	</div>
</div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>