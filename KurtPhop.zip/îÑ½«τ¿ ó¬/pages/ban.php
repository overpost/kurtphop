<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>dropvk | Ошибка!</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Привет! Это сайт мелочей для Вконтакте. Здесь можно установить авто-статус и использовать API VK, а так же скачать PHP скрипты." name="description" />
        <meta content="Скрипты для ВКонтакте, Авто-статус ВК, WALLBOT для вконтакте,статусы для вконтакте,бот для вконтакте,скрипты для вк,меняющиеся статусы вк, настенные бот вк,скрипт для очистки стены вконтакте,скрипты автостатусов вконтакте,php скрипты для вконтакте,API сервисы вконтакте,автоустановка автостатуса вконтакте,как сделать авто-статус вконтакте,php скрипты для вконтакте." name="author" />
        <link href="/assets/css/opes_sans.css" rel="stylesheet" type="text/css"/>
        <link href="/assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="/assets/css/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="/assets/css/lock.min.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="/assets/img_site/favicon.ico" /> </head>
   
    <body class="">
        <div class="page-lock">
            <div class="page-logo">
                <a class="brand">
                    <img src="/resources/img_site/LogoSi.PNG" alt="logo" /> </a>
            </div>
            <div class="page-body">
                <div class="lock-head"> Error</div>
                <div class="lock-body">
                        <h4>Ваш аккаунт был заблокирован. Причину вы сможете узнать у админа.</h4>
                </div>
                <div class="lock-bottom">
                    <h5>Ваш IP адрес: <? echo $_SERVER['REMOTE_ADDR']; ?></h5>
                </div>
            </div>
            <div class="page-footer-custom"> dropvk.cf Copyright @ 2016 </div>
        </div>
<script src="/assets/js/jquery-latest.js"></script>
<script src="/assets/js/jquery.min.js" type="text/javascript"></script>
<script src="/assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/assets/js/jquery.slimscroll.min.js" type="text/javascript"></script>
</body>
</html>