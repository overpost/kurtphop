<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

if (isset($_GET['logout'])) {
if (isset($_SESSION['uid'])) {
function getRealIpAddr() {
  if (!empty($_SERVER['HTTP_CLIENT_IP']))        // Определяем IP
  { $ip=$_SERVER['HTTP_CLIENT_IP']; }
  elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))    // Если IP идёт через прокси
  { $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; }
  else { $ip=$_SERVER['REMOTE_ADDR']; }
  return $ip;
}
if (strstr($_SERVER['HTTP_USER_AGENT'], 'YandexBot')) {$bot='YandexBot';}
elseif (strstr($_SERVER['HTTP_USER_AGENT'], 'Googlebot')) {$bot='Googlebot';}
else { $bot=$_SERVER['HTTP_USER_AGENT']; }
$ip = getRealIpAddr();

$tstamp = date('Y-m-d H:i:s');
$mysqli->query('UPDATE `users` SET `lastjoin`="'.$tstamp.'", `ip_user`="'.$ip.'" WHERE `profile`="'.$_SESSION["uid"].'"');

$_SESSION = array();
session_destroy();
header("Location: /");
} else { header("Location: /"); } }
?>