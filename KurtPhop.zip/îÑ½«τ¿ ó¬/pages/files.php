<?
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Файлы';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-md-12">
<? session_start(); 
include($_SERVER['DOCUMENT_ROOT'].'/cpanel/connect.php');
if (isset($_GET['stats'])) {
$check = $mysqli->query('SELECT * FROM `stats` ORDER BY `id` DESC');
while($row = $check->fetch_array()) {
$id = $row["id"];
$image = $row["image"];
$link = $row["link"];
$comment = $row["comment"];
echo '
<div class="portlet box green">
	<div class="portlet-title">
		<div class="tools">
			<span class="day">
			<i class="fa fa-calendar"> </i> #</span> <span class="day hidden-xs"><i class="fa fa-comment"></i> '.$comment.'</span>
		</div>
		<div class="caption">
			Статус #'.$id.'
		</div>							
	</div>
	<div class="portlet-body">
		<div class="table-responsive">
			<table class="table table-bordered">
				<tbody>
					<tr>			
						<td class="web-inspector-hide-shortcut"><center><img src="'.$image.'"></center></td>
					</tr>
					<tr>			
						<td class="web-inspector-hide-shortcut"><center></center></td>
					</tr>
					<tr>
						<td><div class="btn-group-justified">
							<a href="'.$link.'" class="btn green"> Скачать </a>
						</div></td>
						<input type="hidden" id="script" name="script" value="1">
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
';
}
}

if (isset($_GET['scripts'])) { 
$res = $mysqli->query('SELECT * FROM `script` ORDER BY `id` DESC');
while($row = $res->fetch_array()) {
$id = $row["id"];
$image = $row["image"];
$link = $row["link"];
$comment = $row["comment"];
echo '
<div class="portlet box green">
	<div class="portlet-title">
		<div class="tools">
			<span class="day">
			<i class="fa fa-calendar"> </i> Хз:D</span> <span class="day hidden-xs"><i class="fa fa-comment"></i> '.$comment.'</span>
		</div>
		<div class="caption">
			Скрипт #'.$id.'
		</div>							
	</div>
	<div class="portlet-body">
		<div class="table-responsive">
			<table class="table table-bordered">
				<tbody>
					<tr>			
						<td class="web-inspector-hide-shortcut"><center><img src="'.$image.'"></center></td>
					</tr>
					<tr>			
						<td class="web-inspector-hide-shortcut"><center></center></td>
					</tr>
					<tr>
						<td><div class="btn-group-justified">
							<a href="'.$link.'" class="btn green"> Скачать </a>
						</div></td>
						<input type="hidden" id="script" name="script" value="1">
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
';
} }
?>
</div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>