<?
// Setting //

$config["datafile"] = "./data.txt";
?>