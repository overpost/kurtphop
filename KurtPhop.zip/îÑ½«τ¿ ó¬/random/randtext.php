<?
include "config.php";
 mt_srand ((float) microtime() * 1000000);
 $fp = file($config["datafile"]);
 $count = count($fp) - 1;
 $text = $fp[mt_rand(0,$count)];

 if (empty($type)) 
   {
	echo $text;
   }
 else 
   {
	$fp = file($type . ".inc.php");
	for($i = 0 ; $i < count($fp); $i++)
	  {
	    $fp[$i] = str_replace("<!!text!!>",$text,$fp[$i]);
	    echo $fp[$i];
	    flush();
	  }
   }
?>