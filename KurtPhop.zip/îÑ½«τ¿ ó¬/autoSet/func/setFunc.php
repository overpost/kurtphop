<? session_start();
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Установки функций';
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$checkBan = $mysqli->query('SELECT `ban` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $checkBan->fetch_array()) {
$ban = $row['ban'];
}
if($ban == 2){
die('Ваш аккаунт заблокирован системой ACC');
}else{ ?>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<?php
      include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

      if (isset($_POST['token']) & isset($_POST['online']) & isset($_POST['friends_add']) & isset($_POST['friends_delete'])){
        $token = htmlspecialchars($_POST['token']);
        $online = htmlspecialchars($_POST['online']);
        $city = htmlspecialchars($_POST['city']);
        $friends_add = htmlspecialchars($_POST['friends_add']);
        $friends_delete = htmlspecialchars($_POST['friends_delete']);
        
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$token);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){

         $users_get = curl('https://api.vk.com/method/users.get?name_case=Nom&access_token='.$token);
         $json = json_decode($users_get,1);
         $user_id = $json['response']['0']['uid'];
		 
	$sql1 = $mysqli->query('SELECT * FROM `set_func`');
    
    while($db = $sql1->fetch_array()) {
	$user_id1 = $db['user_id'];
    if($user_id1 == $user_id){
						$povtor = '1';
						break;
	}
	}
	if ($povtor == '1') {
		    echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Аккаунт уже есть в базе</li></ul></div>';
	} else {

		if (is_numeric($length) == true) {
							if ($length > 32) {
								$length = 32;
							}
						} 
						else {
							$length = rand(8, 8);
						}
							$return = array("1","2","3","4","5","6","7","8","9","0");
							for ($i = 0; $i < $length; $i++) {
								$index = rand(0, count($return) - 1);
								$key .= $return [$index];
							}

        echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Функции установлены на аккаунт</li></ul></div>';
        $mysqli->query('INSERT INTO `set_func` (`user_id`, `token`, `friends_add`, `friends_delete`, `online`)
        VALUES("'.$user_id.'", "'.$token.'", "'.$friends_add.'", "'.$friends_delete.'", "'.$online.'")');
        
$message = '';
$messages_send = curl('https://api.vk.com/method/messages.send?user_id='.$user_id.'&message='.urlencode($message).'&access_token='.$token);
	}
	}else{
     echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Неверный токен</li></ul></div>';
    }
        }
          ?>

<? session_start();
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
 }
?>
<div class="col-sm-12">
<form method="post">
<div id="info"></div>
<div class="col-md-12">
<div class="portlet box blue ">
<div class="portlet-title">
    <div class="caption">Установка функций</div>
    <div class="tools">
        <a href="" class="collapse" data-original-title="" title=""> </a>
        <a href="#portlet-config" data-toggle="modal" class="config" data-original-title="" title=""> </a>
        <a href="" class="reload" data-original-title="" title=""> </a>
        <a href="" class="remove" data-original-title="" title=""> </a>
    </div>
</div>
<div class="portlet-body form">
    
        <div class="form-body">
            <div class="panel">
			
<li class="list-group-item">
<div class="input-group">
<span class="input-group-addon">Ваш Access_Token</span>
<input type="text" name="token" id="token" class="form-control" required="required">
</div>
</li>

  <br>
<li class="list-group-item">
<b>2.</b>. Принимать входящие заявки в друзья?
</li>
<li class="list-group-item">
<select class="form-control" name="friends_add">
<option value="1">Нет</option>
<option value="2">Да</option>
</select>
</li>
<li class="list-group-item">
<b>3.</b>. Отпиcываться от тех, кто удалил из друзей?
</li>
<li class="list-group-item">
<select class="form-control" name="friends_delete">
<option value="1">Нет</option>
 <option value="2">Да</option>
</select>
</li>

<li class="list-group-item">
<b>4.</b>. Поддерживать аккаунт в онлайне?
</li>
<li class="list-group-item">
<select class="form-control" name="online">
<option value="1">Нет</option>
<option value="2">Да</option>
</select>
</li>
</div>
        </div>

        <div class="form-actions">
            <button type="setFunc" id="setFunc" name="setFunc" class="btn red">Подтвердить</button>
<button onclick="window.open('http://oauth.vk.com/authorize?client_id=3116505&amp;scope=friends,photos,audio,video,docs,notes,pages,status,offers,questions,wall,groups,messages,notifications,stats,ads,market,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')" class="btn btn-info btn-ef btn-ef-3 btn-ef-3c">Токен</button>
<div id="wait" class="btn default purple-stripe" style="display: none;"><i class="fa fa-spin fa-cog"></i> Загрузка информации </div>
        </div>
    
</div>
  </div></div></form></div>
<? } else { echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Вы не авторизированы</li></ul></div>'; } } ?>
<?
function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
}?>
<?
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>