<? session_start();

    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Смена статуса';

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$checkBan = $mysqli->query('SELECT `ban` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $checkBan->fetch_array()) {
$ban = $row['ban'];
}
if($ban == 2){
die('Ваш аккаунт заблокирован системой ACC');
}else{ ?>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-sm-12">
<?php
include($_SERVER['DOCUMENT_ROOT'].'/cpanel/connect.php');
if (isset($_POST['change']) && isset($_POST['token']) && isset($_POST['numStatus'])){
$token = htmlspecialchars($_POST['token']);
$num = htmlspecialchars($_POST['numStatus']);

$users_get = curl('https://api.vk.com/method/users.get?name_case=Nom&fields=uid&access_token='.$token);
$json = json_decode($users_get,1);
$uid = $json['response']['0']['uid'];

	$sql1 = $mysqli->query('SELECT * FROM `status`');
    while($db = $sql1->fetch_array()) {
	$uid1 = $db['user_id'];
    if($uid1 == $uid){
        $success = '1';
	}
	}
	if ($success == '1') {
echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Готово. Статус изменён</li></ul></div>';
$mysqli->query('UPDATE `status` SET `status_id`="'.$num.'" WHERE `user_id`="'.$uid.'"');

} else {
echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Неизвестная ошибка</li></ul></div>';
    }
}
?>

<? session_start();
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
 }
?>
<form method="post">
<div id="info"></div>
<div class="col-md-12">
<div class="portlet box blue ">
<div class="portlet-title">
    <div class="caption">
    <i class="fa fa-code"></i> Смена статуса</div>
    <div class="tools">
        <a href="" class="collapse" data-original-title="" title=""> </a>
        <a href="#portlet-config" data-toggle="modal" class="config" data-original-title="" title=""> </a>
        <a href="" class="reload" data-original-title="" title=""> </a>
        <a href="" class="remove" data-original-title="" title=""> </a>
    </div>
</div>
<div class="portlet-body form">
    <form role="form">
        <div class="form-body">
            <div class="panel">
<li class="list-group-item">
<div class="input-group">
<span class="input-group-addon">Ваш Access_Token</span>
<input type="text" name="token" id="token" class="form-control" required="required">
</div>
</li>
<br><input type="hidden" name="type" value="s">
<li class="list-group-item">Выберите номер статуса
</li>
<li class="list-group-item">
<select class="form-control" name="numStatus">
<option value="1">1 Статус</option>
<option value="2">2 Статус</option>
<option value="3">3 Статус</option>
<option value="4">4 Статус</option>
<option value="5">5 Статус</option>
<option value="6">6 Статус</option>
<option value="7">7 Статус</option>
<option value="8">8 Статус</option>
</select>
</li>
</div>
        </div>

        <div class="form-actions">
            <button type="change" id="change" name="change" class="btn red">Подтвердить</button>
<button onclick="window.open('http://oauth.vk.com/authorize?client_id=3116505&amp;scope=friends,photos,audio,video,docs,notes,pages,status,offers,questions,wall,groups,messages,notifications,stats,ads,market,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')" class="btn btn-info btn-ef btn-ef-3 btn-ef-3c">Токен</button>
<div id="wait" class="btn default purple-stripe" style="display: none;"><i class="fa fa-spin fa-cog"></i> Загрузка информации </div>
        </div>
    </form>
</div>
  </div></div>
<? } else { echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Вы не авторизированы</li></ul></div>'; } } ?>
<?
function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
}?>
 <?
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>