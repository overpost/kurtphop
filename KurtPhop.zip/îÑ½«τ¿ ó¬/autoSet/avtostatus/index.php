<? 
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Автостатусы';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-md-12">
	<div class="portlet box blue">
		<div class="portlet-title">
			<div class="caption">Раздел: Автостатусы</div>
		</div>
		<div class="portlet-body">
		<a href="setStatus.php" class="list-group-item list-group-item-default" data-original-title="" title="">Поставить Статус</a>
		<a href="Change.php" class="list-group-item list-group-item-default" data-original-title="" title="">Быстра смена статуса</a>
        <a href="Delete.php" class="list-group-item list-group-item-default" data-original-title="" title="">Удалить Статус</a>
		</div>
	</div>
</div>
<?
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>