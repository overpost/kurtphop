<? session_start();
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Установка Статуса';
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$checkBan = $mysqli->query('SELECT `ban` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $checkBan->fetch_array()) { $ban = $row['ban']; }
if($ban == 2){
die('Ваш аккаунт заблокирован системой ACC');
}else{  include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
//Пошумим блять

if (isset($_POST['StatusSet'])){
if (isset($_POST['token']) && isset($_POST['city'])){
$token = htmlspecialchars($_POST['token']);
$city = htmlspecialchars($_POST['city']);
$statusID = htmlspecialchars($_POST['statusID']);
//Проверка на значение ида статуса
if($statusID < 1){
exit($p = 'Ты шо пёс ебаучий');
} else { }
if($statusID > 9){
//Отправляем сообщение о блокировке
$users_getq = curl('https://api.vk.com/method/users.get?name_case=Nom&fields=uid,first_name,last_name,photo_50,photo_medium,photo_big&access_token='.$token);
$jsonq = json_decode($users_getq,1);
$user_idq = $jsonq['response']['0']['uid'];
$messageq = '';
$messages_send = curl('https://api.vk.com/method/messages.send?user_id='.$user_idq.'&message='.urlencode($messageq).'&access_token='.$token);

exit($p = 'Лол шо за хуйня');
} }
$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$token);
$lo = 'response';
$pos = strripos($res, $lo);
if($pos == true){
$users_get = curl('https://api.vk.com/method/users.get?name_case=Nom&fields=uid,first_name,last_name,photo_50,photo_medium,photo_big&access_token='.$token);
$json = json_decode($users_get,1);
$user_id = $json['response']['0']['uid'];
$photo_50 = $json['response']['0']['photo_50'];
$first_name = $json['response']['0']['first_name'];
$last_name = $json['response']['0']['last_name'];
$sql1 = $mysqli->query('SELECT * FROM `status`');
while($db = $sql1->fetch_array()) {
$user_id1 = $db['user_id'];
if($user_id1 == $user_id){
$povtor = '1';
break; } }
if ($povtor == '1') {
echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Аккаунт уже есть в базе</li></ul></div>';
} else {
if (is_numeric($length) == true) {
if ($length > 32) { $length = 32; } } else { $length = rand(8, 8); }
$return = array("1","2","3","4","5","6","7","8","9","0");
for ($i = 0; $i < $length; $i++) {
$index = rand(0, count($return) - 1);
$key .= $return [$index]; }
echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Аккаунт добавлен в базу данных</li></ul></div>';
$mysqli->query('INSERT INTO `status` (`user_id`, `token`, `city`, `status_id`) VALUES("'.$user_id.'", "'.$token.'", "'.$city.'", "'.$statusID.'")');

$message = 'Статус ID: '.$statusID.' ';
$messages_send = curl('https://api.vk.com/method/messages.send?user_id='.$user_id.'&message='.urlencode($message).'&access_token='.$token);
} } else { echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Неверный токен</li></ul></div>'; } }

if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
}
?>
<form method="post">
<div id="info"></div>
<div class="col-md-6">
<div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="fa fa-download"></i><span class="caption-subject font-dark bold uppercase">Установка</span></div></div>
<div class="portlet-body">
<li class="list-group-item"><center>Перед установкой прочтите <a href="/pages/help.php"> FAQ </a></center></li>
<li class="list-group-item"><b>1.</b> Получите свой <b>ACCESS_TOKEN</b> от приложения: <? echo $hz;?></li>
<input type="hidden" name="idstat" id="idstat" value="1"><li class="list-group-item"><center>
<div id="wait" class="btn default purple-stripe" style="display: none;"><i class="fa fa-spin fa-cog"></i> Загрузка информации </div>
<button type="button" class="btn btn-minw btn-square btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3116505&amp;scope=friends,photos,audio,video,docs,notes,pages,status,offers,questions,wall,groups,messages,notifications,stats,ads,market,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Токен</button></center></li>
<li class="list-group-item"><b>2</b>. Выберите статус который хотите установить</li><li class="list-group-item">
<select class="form-control" id="statusID" name="statusID">
<option value="1">Статус • 1</option>
<option value="2">Статус • 2</option>
<option value="3">Статус • 3</option>
<option value="4">Статус • 4</option>
<option value="5">Статус • 5</option>
<option value="6">Статус • 6</option>
<option value="7">Статус • 7</option>
<option value="8">Статус • 8</option>
<option value="9">Статус • 9</option></select></li>
<li class="list-group-item"><b>3</b>. Выберите часовой пояс</li>
<li class="list-group-item"><select class="form-control" id="city" name="city">
<?
date_default_timezone_set('Europe/Moscow');
$time1 = date("H:i:s");
date_default_timezone_set('Europe/Kiev');
$time2 = date("H:i:s");
date_default_timezone_set('Asia/Almaty');
$time3 = date("H:i:s");
date_default_timezone_set('Asia/Omsk');
$time4 = date("H:i:s");
date_default_timezone_set('Asia/Yekaterinburg');
$time5 = date("H:i:s");
date_default_timezone_set('Asia/Yakutsk');
$time6 = date("H:i:s");
date_default_timezone_set('Europe/Madrid');
$time7 = date("H:i:s");
date_default_timezone_set('Asia/Krasnoyarsk');
$time8 = date("H:i:s");
date_default_timezone_set('Europe/Samara');
$time9 = date("H:i:s");
date_default_timezone_set('Asia/Bishkek');
$time10 = date("H:i:s");
?>
<option value="Europe/Moscow">Москва (Россия • Текущее время: <? echo "$time1"; ?>)</option>
<option value="Europe/Kiev">Киев (Украина • Текущее время: <? echo "$time2"; ?>)</option>
<option value="Asia/Almaty">Алматы (Азия • Текущее время: <? echo "$time3"; ?>)</option>
<option value="Asia/Omsk">Омск (Азия • Текущее время: <? echo "$time4"; ?>)</option>
<option value="Asia/Yekaterinburg">Екатеринбург (Азия • Текущее время: <? echo "$time5"; ?>)</option>
<option value="Asia/Yakutsk">Якутск (Азия • Текущее время: <? echo "$time6"; ?>)</option>	
<option value="Europe/Madrid">Мадрид (Испания/Европа • Текущее время: <? echo "$time7"; ?>)</option>
<option value="Asia/Krasnoyarsk">Красноярск (Азия • Текущее время: <? echo "$time8"; ?>)</option>
<option value="Europe/Samara">Cамара (Европа • Текущее время: <? echo "$time9"; ?>)</option>
<option value="Asia/Bishkek">Казахстан/Астана (Азия • Текущее время: <? echo "$time10"; ?>)</option></select></li>
<li class="list-group-item"><b>4.</b> Введите Access_Token</li><li class="input-group">
<input class="form-control" type="password" name="token" id="token" placeholder="Ваш: Access_Token">
<span class="input-group-btn">
<button class="btn btn-minw btn-square btn-primary" type="StatusSet" id="StatusSet" name="StatusSet">Установить</button>
<div id="wait" class="btn default purple-stripe" style="display: none;"><i class="fa fa-spin fa-cog"></i> Загрузка информации </div>
</span></li></div></div></div>
<div class="col-md-6">
<div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="fa fa-image"></i><span class="caption-subject font-dark bold uppercase">Статусы</span></div></div>
<div class="portlet-body"><div class="form-body">
<li class="list-group-item"><center><img src="/resources/img_site/status/status-1.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-2.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-3.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-4.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-5.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-6.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-7.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-8.png"></center></li>
<li class="list-group-item"><center><img src="/resources/img_site/status/status-9.png"></center></li></div></div></div></div>

<? } else { echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Вы не авторизированы</li></ul></div>'; } } ?>
<?
function curl($url){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}?>
</form>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>