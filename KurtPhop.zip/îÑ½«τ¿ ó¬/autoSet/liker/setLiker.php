<? session_start();
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
    $name = $site['Name'];
     $title = ''.$name.' • Установка лайкера';
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$checkBan = $mysqli->query('SELECT `ban` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $checkBan->fetch_array()) {
$ban = $row['ban'];
}
if($ban == 2){
die('Ваш аккаунт заблокирован системой ACC');
}else{ ?>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

if (isset($_POST['token'])){
        $token = htmlspecialchars($_POST['token']);
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$token);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
		
	$users_get = curl('https://api.vk.com/method/users.get?name_case=Nom&access_token='.$token);
         $json = json_decode($users_get,1);
         $user_id = $json['response']['0']['uid'];
		 
	$sql1 = $mysqli->query('SELECT * FROM `sms_bot`');
    
    while($db = $sql1->fetch_array()) {
	$user_id1 = $db['user_id'];
    if($user_id1 == $user_id){
						$povtor = '1';
						break;
	}
	}
	if ($povtor == '1') {
		    echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Аккаунт уже есть в базе</li></ul></div>';
	} else {
     echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Аккаунт добавлен в базу данных</li></ul></div>';
        $mysqli->query('INSERT INTO sms_bot (`user_id`, `token`)
        VALUES("'.$user_id.'", "'.$token.'")');
        
$message = '
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
&#128536; Спасибо за доверие нашему сервису!
&#9786; Всегда ваш Лайкер

💻 Удалить Лайкер можно в разделе!
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖';
$messages_send = curl('https://api.vk.com/method/messages.send?user_id='.$user_id.'&message='.urlencode($message).'&access_token='.$token);
	}
	    }else{
		echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Неверный токен</li></ul></div>';
    } 
  }
?>

<? session_start();
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
 }
?>
<div class="col-sm-12">
<form method="post">
<div id="info"></div>
<div class="col-md-12">
<div class="portlet box blue ">
<div class="portlet-title">
    <div class="caption">Установка  Лайкера</div>
    <div class="tools">
        <a href="" class="collapse" data-original-title="" title=""> </a>
        <a href="#portlet-config" data-toggle="modal" class="config" data-original-title="" title=""> </a>
        <a href="" class="reload" data-original-title="" title=""> </a>
        <a href="" class="remove" data-original-title="" title=""> </a>
    </div>
</div>
<div class="portlet-body form">
    
        <div class="form-body">
            <div class="panel">
<li class="list-group-item">
<div class="input-group">
<span class="input-group-addon">Ваш Access_Token</span>
<input type="text" name="token" id="token" class="form-control" required="required">
</div>
</li>
</div>
        </div>

        <div class="form-actions">
            <button type="StatusSet" id="StatusSet" name="StatusSet" class="btn red">Подтвердить</button>
	<button type="button" class="btn btn-info btn-ef btn-ef-3 btn-ef-3c" onclick="window.open('http://oauth.vk.com/authorize?client_id=3087106&scope=wall,offline&redirect_uri=http://api.vk.com/blank.html&display=page&response_type=token')">Токен</button>

<div id="wait" class="btn default purple-stripe" style="display: none;"><i class="fa fa-spin fa-cog"></i> Загрузка информации </div>
        </div>
    
</div>
  </div></div></form></div>
<? } else { echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Вы не авторизированы</li></ul></div>'; } } ?>
<?
function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
}?>
<?
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>