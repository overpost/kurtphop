<? include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<div class="col-md-12">
	<div class="portlet box blue">
		<div class="portlet-title">
			<div class="caption">Раздел: Лайкер BETA 0.1</div>
		</div>
		<div class="portlet-body">
		<a href="setLiker.php" class="list-group-item list-group-item-default" data-original-title="" title="">Установить Лайкер</a>
        <a href="Delete.php" class="list-group-item list-group-item-default" data-original-title="" title="">Удалить Лайкер</a>
		</div>
	</div>
</div>
<?
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>