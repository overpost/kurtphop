<?php

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

$sql = $mysqli->query('SELECT * FROM `status`');
while($db = $sql->fetch_array()) {
	if($db['status_id']=='8') {
date_default_timezone_set ($db['city']);
$messageGet = curl('https://api.vk.com/method/messages.get?access_token='.$db['token']);
$json = json_decode($messageGet,1);
$countM = $json['response']['0'];
#Дальше лучше не трогать не чего!
$time3 = date("H:i");
$time1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$time2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
$time = ''.str_replace($time1, $time2, $time3).' '; 

$data3 = date("d.m");
$data1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$data2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
$data = ''.str_replace($data1, $data2, $data3).' '; 

$getLikes = curl('https://api.vk.com/method/photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
$getLikesJson = json_decode($getLikes,1);
$likes = $getLikesJson['response']['0']['likes']['count'];

$smiles = array("😸", "🙀", "😿","😾", "😹", "😼", "😻", "😎","😉", "😈", "😂", "😃", "😀", "😍", "😜", "❤", "💎");
$rand = rand(0,count($smiles) - 1);  
$hurt = $smiles[$rand]; 

#Тут наши подписчики
$getInfo = curl('https://api.vk.com/method/users.get?access_token='.$db['token'].'&fields=uid,first_name,last_name,nickname,screen_name,sex,bdate,city,country,timezone,photo,photo_medium,photo_big,has_mobile,rate,contacts,education,online,counters');
$json2 = json_decode($getInfo,1);
$countR = $json2['response']['0']['counters']['followers'];

$Uservk = curl('https://api.vk.com/method/users.get?name_case=nom&access_token='.$db['token']);
$json = json_decode($Uservk,1);
$userid = $json['response']['0']['uid'];

#Погода
$weater = file_get_contents("http://informer.gismeteo.ru/xml/27595_1.xml");
$xml = xml_parser_create();
$indexes = array();
$values = array();
xml_parse_into_struct($xml,$weater, $values, $indexes);
xml_parser_free($xml);
$wiz = $values[38][attributes][MAX]; 

$status = "⏰ $time • 📅  $data | ✉ $countM | 🔖 $countR | $hurt"; 
//$status = "    $time| $hurt на аве лайков: $likes | $data           $ID";
$statusSet = curl('https://api.vk.com/method/status.set?text='.urlencode($status).'&v=3.0&access_token='.$db['token']);
	}}
function curl( $url ){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
?>