﻿<?
      include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

	$sql1 = $mysqli->query('SELECT * FROM `lt`');
    while($db = $sql1->fetch_array()) {

$token = $db['token'];
$owner_id = $db['user'];
$offset = "0";
$count = "10";
header("Content-Type: text/html; charset=cp1252");
date_default_timezone_set ("Europe/Kiev");
$get = json_decode(file_get_contents('https://api.vk.com/method/wall.get?offset='.$offset.'&owner_id='.$owner_id.'&count=1&v=5.44&access_token='.$token),1)['response']['items'][0]['id'];  
$likes = json_decode(file_get_contents('https://api.vk.com/method/likes.getList?type=post&owner_id='.$owner_id.'&item_id='.$get.'&v=5.44&filter=likes&access_token='.$token),1)['response']['items']; 
if(count($likes)<$count){echo "no";die();} 
shuffle($likes);
if(count($likes)>10){$likes = array_slice($likes,0,10);}
for($i = 0; $i < count($likes); $i++){
$photos = json_decode(file_get_contents('https://api.vk.com/method/photos.get?album_id=profile&count=1&rev=1&owner_id='.$likes[$i].'&v=5.44&access_token='.$token),1)['response']['items'];  
$pht[] = 'photo'.$photos[0]['owner_id'].'_'.$photos[0]['id'];
}
$users = '*id'.join(', *id',$likes);
$att = join(',',$pht);
$res = file_get_contents('http://www.factroom.ru/random/');
preg_match('/title="(.*?)" data/', $res, $fact);
$smiles = array(array('👻','👽','👾','🤗','😎','👍','👀','🍭','🍬','🍫','🍰','🎂','🍪','🍩','🍨','🍧','🍦','🍡','🍥'),array('💙','💚','💛','💜','❤'),array('💝','💞','💟','💗','❣','💌','👄','💋','💘','💓','💕','💖'));
$sm1 = $smiles[0][array_rand($smiles[0])];
$sm2 = $smiles[2][array_rand($smiles[2])];
$text = $sm1.' Победители: '.$users.'  '.$sm1.'
'.$smiles[1][array_rand($smiles[1])].' Чтобы попасть в #ЛайкТайм  '.$smiles[1][array_rand($smiles[1])].'
'.$sm2.' Лайкни первый пост и все фото в нем  '.$sm2.'
⏬Не забываем лайкать посты ниже⏬
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
✏Теги: #LT #ЛТ #Like_Time #Лайк_Тайм #LikeTime #Likes #Лайки';
$post = json_decode(file_get_contents('https://api.vk.com/method/wall.post?owner_id='.$owner_id.'&from_group=1&message='.urlencode($text).'&attachments='.$att.'&v=5.44&access_token='.$token),1);  
print_r($post);
function curl($url) {
		$ch = curl_init($url);
		curl_setopt ($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt ($ch,CURLOPT_SSL_VERIFYHOST,false);
		curl_setopt ($ch,CURLOPT_SSL_VERIFYPEER,false);
		$response = curl_exec($ch);
		curl_close ($ch);
		return $response;
	}
	

?>