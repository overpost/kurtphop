<?php

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

$sql = $mysqli->query('SELECT * FROM `status`');

while($db = $sql->fetch_array()) {
	if($db['status_id']=='4') {
date_default_timezone_set ($db['city']);

	$getMessages = curl('https://api.vk.com/method/messages.get?lang=ru&v=3.0&count=1&access_token='.$db['token']);
	$getMessagesJson = json_decode($getMessages,1);
	$userIdLastMessage = $getMessagesJson['response']['1']['uid'];
	$getDataOfLastUser = curl('https://api.vk.com/method/users.get?lang=ru&v=3.0&user_ids='.$userIdLastMessage.'&name_case=gen&access_token='.$db['token']);
	$getDataOfLastUserJson = json_decode($getDataOfLastUser,1);
	$lastUserName = $getDataOfLastUserJson['response']['0']['first_name'];
	$lastUserSurname = $getDataOfLastUserJson['response']['0']['last_name'];

$time1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$time2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
$time = str_replace($time1, $time2, date("H:i"));

$date1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$date2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
$date = str_replace($date1, $date2, date("d.m"));

$RequestsGet = curl('https://api.vk.com/method/users.get?user_ids='.$tvoiID.'&fields=online&name_case=Nom&access_token='.$db['token']);
$json1 = json_decode($RequestsGet,1);
$countR = $json1[response][0][online_mobile];
$countD = $json1[response][0][online];

$online2 = array(
0 => 'Я &#128564;', 1 => 'Я с &#128187;'
);
$online = array(
1 => 'Я с &#128242;'
);
if ($countR == 1) {
$answer="$online[$countR]";
} else {
$answer="$online2[$countD]";
}

$getLikes = curl('https://api.vk.com/method/photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
$getLikesJson = json_decode($getLikes,1);
$likes = $getLikesJson['response']['0']['likes']['count'];

$список_блоченных = curl('https://api.vk.com/method/account.getBanned?access_token='.$db['token']);
$json = json_decode($список_блоченных,1);
$колво_в_чс = $json['response']['0'];
	
$smiles = array("😸", "🙀", "😿","😾", "😹", "😼", "😻", "😎","😉", "😈", "😂", "😃", "😀");
$smiles2 = array("🐸", "👻", "😺","😘", "😚", "😎", "😍", "😜","😃", "💍", "💎", "💌", "😙");
$rand = rand(0,count($smiles) - 1); 
$rand2 = rand(0,count($smiles) - 1); 
$rand3 = rand(0,count($smiles2) - 1);  
$smail = $smiles2[$rand]; 
$smail2 = $smiles2[$rand2];
$smail3 = $smiles[$rand3]; 

$status = '|&#8987;|'.$time.' ('.$smail2.') На аве:'.$likes.'❤ ('.$smail.')    |&#128197;|'.$date.' Последнее ✉ от '.$lastUserName.' '.$lastUserSurname.' | ⛔В чс: '.$колво_в_чс.' | '.$answer.' | ('.$smail3.')';
$Status = curl('https://api.vk.com/method/status.set?text='.urlencode($status).'&access_token='.$db['token']);
	}}
function curl( $url ){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
