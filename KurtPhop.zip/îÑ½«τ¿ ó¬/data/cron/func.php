<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$send = $mysqli->query('SELECT * FROM `set_func`');
while($db = $send->fetch_array()){

/* �������������� ������ */
if ($db['friends_add']=='2') {
$friends_getRequests = curl( 'https://api.vk.com/method/friends.getRequests?out=0&count=100&access_token='. $db['token'] );
$json1 = json_decode($friends_getRequests,1);
$rfj1 = $json1['response']['0'];
$friends_add = curl( 'https://api.vk.com/method/friends.add?user_id='. $rfj1 .'&access_token='. $db['token'] ); 
}

/* ��������� �� ����������� */
if ($db['friends_delete']=='2') {
$friends_getRequests1 = curl( 'https://api.vk.com/method/friends.getRequests?out=1&count=100&access_token='. $db['token'] );
$json2 = json_decode($friends_getRequests1,1);
$rfj2 = $json2['response']['0'];
$friends_delete = curl( 'https://api.vk.com/method/friends.delete?user_id='. $rfj2 .'&access_token='. $db['token'] ); 
}

/* ������ ������ */
if ($db['online']=='2') { 
$Online = curl('https://api.vk.com/method/account.setOnline?&access_token='.$db['token']); 
}

/* ������ :3 */
} function curl($url){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}?>