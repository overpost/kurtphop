<?php

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

$sql = $mysqli->query('SELECT * FROM `status`');

while($db = $sql->fetch_array()) {
	if($db['status_id']=='7') {
date_default_timezone_set ($db['city']);
							
						$by = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");
	$srv = array("1⃣", "2⃣", "3⃣", "4⃣", "5⃣", "6⃣", "7⃣", "8⃣", "9⃣", "0⃣");
							$smi3 = "                ".str_replace($by, $srv, date("H:i"))."                        ".str_replace($by, $srv, date("d.m.Y"))."";

$statusSet = curl('https://api.vk.com/method/status.set?text='.urlencode($smi3).'&access_token='.$db['token']);
	}}
function curl( $url ){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
