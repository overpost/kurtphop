<?php
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

    $sql = $mysqli->query('SELECT * FROM `online`');
    while($token = $sql->fetch_array()) {
    $url = "https://api.vk.com/method/account.setOnline?access_token=".$token['token']."";
    file_get_contents($url);
      }
?>