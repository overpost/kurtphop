<?php

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

$sql = $mysqli->query('SELECT * FROM `status`');
while($db = $sql->fetch_array()) {
	if($db['status_id']=='10') {
date_default_timezone_set ($db['city']);

$time3 = date("H:i");
$time1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$time2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
$time = ''.str_replace($time1, $time2, $time3).' '; 

$data3 = date("d.m");
$data1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$data2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
$data = ''.str_replace($data1, $data2, $data3).' '; 

$getLikes = curl('https://api.vk.com/method/photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
$getLikesJson = json_decode($getLikes,1);
$likes = $getLikesJson['response']['0']['likes']['count'];

#Рандом сердечьки
$time = explode(':', date('H:i')); //vk.com/almazik2015
$emojiTime = array('0⃣', '1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣',  '🔟'); //almazik2015.tw1.ru
$times1 = $emojiTime[$time[0][0]] . $emojiTime[$time[0][1]]; //Часы 
$times2 = $emojiTime[$time[1][0]] . $emojiTime[$time[1][1]]; //Минуты 
$date = explode('/', date('d/m/')); //vk.com/almazik2015
$emojiDate = array('0⃣', '1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣',  '🔟'); //almazik2015.tw1.ru
$dates1 = $emojiDate[$date[0][0]] . $emojiDate[$date[0][1]]; //День
$dates2 = $emojiDate[$date[1][0]] . $emojiDate[$date[1][1]]; //Месяц 
$god = '.2&#8419;0&#8419;1&#8419;4&#8419;'; //Год (При желание оставьте пустым) //vk.com/almazik2015
$add1 = 'Время: '.$times1.':'.$times2.' '; //Время 
$add2 = 'Дата: '.$dates1.'.'.$dates2.''.$god.' '; //Дата 
//Можете_удалить ▼ //vk.com/almazik2015
$by = '&#9408;&#9444;&#9441;&#9443;&#9413;&#9431;&#9438;&#9439;.&#9413;&#9420;'; //При желание можете удалить! 
//Можете_удалить ▲______________▼_И_Это //vk.com/almazik2015
$status = ''.$add1.''.$add2.''.$by.''; //Выводим статус
$statusSet = curl('https://api.vk.com/method/status.set?text='.urlencode($status).'&v=3.0&access_token='.$db['token']);
	}}
function curl( $url ){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
?>