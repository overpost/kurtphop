<?php

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

$sql = $mysqli->query('SELECT * FROM `status`');
while($db = $sql->fetch_array()) {
	if($db['status_id']=='3') {
	
date_default_timezone_set ($db['city']);

$time = date("H:i");
$date = date("d.m");

$messageGet = curl('https://api.vk.com/method/account.getBanned?access_token='.$db['token']);
$json = json_decode($messageGet,1);
$countM = $json['response']['0'];

$a7 = "  В чёрным списке: $countM";
$a8 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$a9 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

$a1 = "$time";
$a2 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$a3 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

$a4 = "$date";
$a5 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$a6 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

$smiles = array("😸", "🙀", "😿","😾", "😹", "😼", "😻", "😎","😉", "😈", "😂", "😃", "😀");
$rand = rand(0,count($smiles) - 1);  
$hurt = $smiles[$rand]; 

$getInfo = curl('https://api.vk.com/method/users.get?access_token='.$db['token'].'&fields=uid,first_name,last_name,nickname,screen_name,sex,bdate,city,country,timezone,photo,photo_medium,photo_big,has_mobile,rate,contacts,education,online,counters');
$json2 = json_decode($getInfo,1);
$fonline = $json2['response']['0']['counters']['online_friends'];
$friends = $json2['response']['0']['counters']['friends'];

$RequestsGet = curl('https://api.vk.com/method/users.get?user_ids='.$tvoiID.'&fields=online&name_case=Nom&access_token='.$db['token']);
$json1 = json_decode($RequestsGet,1);
$countR = $json1[response][0][online_mobile];
$countD = $json1[response][0][online];

$online2 = array(
0 => 'В данный момент я &#128564;    ', 1 => 'В данный момент я с компьютера &#128187;'
);

$online = array(
1 => 'В данный момент я с телефона &#128242;'
);


if ($countR == 1) {
$answer="$online[$countR]";
} else {
$answer="$online2[$countD]";
}

$status = (''.str_replace($a2, $a3, $a1).'            '.$hurt.'              '.str_replace($a5, $a6, $a4).' '.str_replace($a8, $a9, $a7).' | '.$answer.'         Online '.$fonline.' из '.$friends.'');
$statusSet = curl('https://api.vk.com/method/status.set?text='.urlencode($status).'&access_token='.$db['token']);
	}}
function curl( $url ){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}