<?php

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
	
$sql = $mysqli->query('SELECT * FROM `status`');

while($db = $sql->fetch_array()) {
	if($db['status_id']=='6') {
date_default_timezone_set ($db['city']);

$time = date("H:i");

$date1 = date("d.m");

$getLikes = curl('https://api.vk.com/method/photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
$getLikesJson = json_decode($getLikes,1);
$likes = $getLikesJson['response']['0']['likes']['count'];

$messageGet = curl('https://api.vk.com/method/messages.get?count=1&access_token='.$db['token']);
$json = json_decode($messageGet,1);
$countM = $json['response']['0'];

$smiles = array("😼", "😸", "😆", "😾", "😚","😸", "😽", "😉", "😊", "😉", "😘", "😼", "😽", "😾", "😉", "🐩", "😜", "😽" );
$rand = rand(0,count($smiles) - 1);  
$hurt = $smiles[$rand]; 
$res = file_get_contents('http://kurtphop.pw/random/randtext.php');

							$smi3 = "$time • Факт: $res";
$smi = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
$smi2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

$status = ''.str_replace($smi, $smi2, $smi3).' '; 
$statusSet = curl('https://api.vk.com/method/status.set?text='.urlencode($status).'&access_token='.$db['token']);
	}}
function curl( $url ){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
