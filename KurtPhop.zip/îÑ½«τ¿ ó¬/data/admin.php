<?
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$site = $mysqli->query('SELECT * FROM `site`')->fetch_array();
$name = $site['Name'];
$title = ''.$name.' •  Админка';
session_start();
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT `admin` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
$admin = $row['admin']; } }
if($admin == 2) {} else{ header("Location: /"); }
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
if (!$_GET) { echo '<div class="col-md-12"><div class="portlet box green">
<div class="portlet-title"><div class="caption">Админ панель</div></div><div class="portlet-body"><div class="form-body">
<li class="list-group-item">Выберите функцию</li><li class="list-group-item">
<center>
<a href="?system"><button type="button" class="btn btn-danger btn-circle">Системные настройки</button></a>
<a href="?ipTable"><button type="button" class="btn btn-success btn-circle">Таблица IP_Users</button></a>
<a href="?script"><button type="button" class="btn btn-danger btn-circle">Скрипты</button></a>
<a href="?status"><button type="button" class="btn btn-success btn-circle">Статусы</button></a>
<a href="?users"><button type="button" class="btn btn-danger btn-circle">Редактирование пользователей</button></a>'; } ?>

<? if (isset($_GET['system'])) {
$fullInfo = $mysqli->query('SELECT * from `site`');
$infoFetch = $fullInfo->fetch_array();
$name = $infoFetch['Name'];
$aac = $infoFetch['AAC'];
$theme = $infoFetch['theme'];
if($aac == '1') {
$aac1 = '<option value="1">AAC • Работает</option><option value="2">AAC • IP Баны выключены</option>';
} else { $aac1 = '<option value="2">AAC • IP Баны выключены</option><option value="1">AAC • Работает</option>'; }

if ($theme == '1') {
$themeSel = '
<option value="1">Тема • Стандарт</option>
<option value="2">Тема • Тёмная</option>
<option value="3">Тема • Синяя</option>
<option value="4">Тема • Грей</option>
<option value="5">Тема • Светлая</option>
<option value="6">Тема • Светлая (2)</option>
'; }	
if ($theme == '2') {
$themeSel = '
<option value="2">Тема • Тёмная</option>
<option value="1">Тема • Стандарт</option>
<option value="3">Тема • Синяя</option>
<option value="4">Тема • Грей</option>
<option value="5">Тема • Светлая</option>
<option value="6">Тема • Светлая (2)</option>
'; }
if ($theme == '3') {
$themeSel = '
<option value="3">Тема • Синяя</option>
<option value="1">Тема • Стандарт</option>
<option value="2">Тема • Тёмная</option>
<option value="4">Тема • Грей</option>
<option value="5">Тема • Светлая</option>
<option value="6">Тема • Светлая (2)</option>
'; }
if ($theme == '4') {
$themeSel = '
<option value="4">Тема • Грей</option>
<option value="1">Тема • Стандарт</option>
<option value="2">Тема • Тёмная</option>
<option value="3">Тема • Синяя</option>
<option value="5">Тема • Светлая</option>
<option value="6">Тема • Светлая (2)</option>
'; }
if ($theme == '5') {
$themeSel = '
<option value="5">Тема • Светлая</option>
<option value="1">Тема • Стандарт</option>
<option value="2">Тема • Тёмная</option>
<option value="3">Тема • Синяя</option>
<option value="4">Тема • Грей</option>
<option value="6">Тема • Светлая (2)</option>
'; }
if ($theme == '6') {
$themeSel = '
<option value="6">Тема • Светлая (2)</option>
<option value="1">Тема • Стандарт</option>
<option value="2">Тема • Тёмная</option>
<option value="3">Тема • Синяя</option>
<option value="4">Тема • Грей</option>
<option value="5">Тема • Светлая</option>
'; }

if(isset($_POST['charge'])){
$site_name = htmlspecialchars($_POST['site_name']);
$aacMode = htmlspecialchars($_POST['aacMode']);
$theme = htmlspecialchars($_POST['theme']);
if(empty($site_name)){
echo '<div class="col-md-12"><div class="alert alert-warning alert-dismissable">ti daun? Название сайта введи</div></div>';
} else {
$mysqli->query('UPDATE `site` SET `Name`="'.$site_name.'", `AAC`="'.$aacMode.'", `theme`="'.$theme.'"');
echo '<div class="col-md-12"><div class="alert alert-info alert-dismissable">Данные обновлены</div></div>';
} }
?>
<div class="col-md-12">
<form method="post">
<div class="portlet box green"><div class="portlet-title">
<div class="caption"><i class="fa fa-download"></i><span class="caption">Системные настройки</span></div></div>
<div class="portlet-body">
<li class="list-group-item"><b>1</b> . Работа системы блокировок AAC / IP Ban</li><li class="list-group-item">
<select class="form-control" id="aacMode" name="aacMode"><? echo $aac1; ?></select></li>

<li class="list-group-item"><b>2</b> . Тема сайта</li><li class="list-group-item">
<select class="form-control" id="theme" name="theme"><? echo $themeSel; ?></select></li>

<li class="list-group-item"><b>3</b>. Название сайта</li><li class="input-group">
<input class="form-control" type="text" name="site_name" id="site_name" value="<? echo $name; ?>" placeholder="Название сайта">
<span class="input-group-btn"><button class="btn btn-minw btn-square btn-primary" type="charge" id="charge" name="charge">Изменить</button>
</span></li></div></div></form></div>
<? } ?>

<? if (isset($_GET['users'])) { ?>
<div class="col-md-12">
<div class="portlet box green">
<div class="portlet-title tabbable-line">
<div class="caption">
<i class="icon-bubbles font-dark hide"></i>
<span class="caption">Редактирование пользователей</span>
</div>
</div>
<div class="portlet-body">
<div class="tab-pane active" id="portlet_comments_1">
<div class="mt-comments">
<? $sql = $mysqli->query('SELECT * FROM `users` ORDER BY `id` DESC');
while($row = $sql->fetch_array()) {
$id = $row["id"];
$first_name = $row["first_name"];
$last_name = $row["last_name"];
$photo = $row["photo"];
$admin = $row["admin"];
$datereg = $row["datereg"];
$ban = $row["ban"];
if($ban == 2){
$statusUser = "<span class='text-danger'>Banned</span>";
}else{ 
if($admin == 2){
$statusUser = "<div class='text-success'>Администратор</div>";
}else{
$statusUser = "Пользователь";
} } echo '<div class="mt-comment">
<div class="mt-comment-img">
<img src="'.$photo.'" style="wight:40px;height:40px"> </div>
<div class="mt-comment-body">
<div class="mt-comment-info">
<span class="mt-comment-author">'.$first_name.' '.$last_name.'</span>
<span class="mt-comment-date">'.$datereg.'</span>
</div><div class="mt-comment-details">
<span class="mt-comment-status mt-comment-status-pending">'.$statusUser.'</span>
<ul class="mt-comment-actions">
<li><a href="/data/admin?editUser='.$id.'">Изменить</a></li><li><a href="/id'.$id.'">Профиль</a></li>
</ul></div></div></div>'; } ?>
</tbody></table></div></div></div></div>




<? } if (isset($_GET['editUser'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `id` = "'.$_GET['editUser'].'"');
while($row = $sql->fetch_array()) {
$id = $row['id'];
$fname = $row['first_name'];
$lname = $row['last_name'];
$ph = $row['photo'];
$bn = $row['ban'];
$ad = $row['admin'];
$mn = $row['money'];
$hd = $row['hidden'];
$vr = $row['verify'];
$up = $row['ip_user']; }
if($ad == 2){ $a = "<option value='2'>Администратор</option> <option value='1'>Пользователь</option>"; }else{ 
$a = "<option value='1'>Пользователь</option> <option value='2'>Администратор</option>"; }
if($bn == 2){
if (isset($_POST['block'])) { $mysqli->query('UPDATE `users` SET `ban`="1" WHERE `id`="'.$id.'"');
$mysqli->query('UPDATE `ip_users` SET `ban`="1" WHERE `ip`="'.$up.'"');}
$bn = '<button class="btn red fa fa-times-circle" type="block" id="block" name="block"> Разблокировать</button>';
}else{ 
if (isset($_POST['block'])) { $mysqli->query('UPDATE `users` SET `ban`="2" WHERE `id`="'.$id.'"');
$mysqli->query('UPDATE `ip_users` SET `ban`="2" WHERE `ip`="'.$up.'"'); }
$bn = '<button class="btn red fa fa-times-circle" type="block" id="block" name="block"> Заблокировать</button>'; }
if($hd == 2){
if (isset($_POST['hide-out'])) { $mysqli->query('UPDATE `users` SET `hidden`="1" WHERE `id`="'.$id.'"'); }
$hd = '<button class="btn purple fa fa-user-secret" type="hide-out" id="hide-out" name="hide-out"> Показать профиль</button>'; }else{
if (isset($_POST['hide-out'])) { $mysqli->query('UPDATE `users` SET `hidden`="2" WHERE `id`="'.$id.'"'); }
$hd = '<button class="btn purple fa fa-user-secret" type="hide-out" id="hide-out" name="hide-out"> Скрыть профиль</button>';}
if($vr == 2){
if (isset($_POST['verif'])) {
$mysqli->query('UPDATE `users` SET `verify`="1" WHERE `id`="'.$id.'"'); }
$vr = '<button class="btn blue fa fa-check" type="veri" id="veri" name="verif"> Убрать верификацию</button>'; }else{
if (isset($_POST['verif'])) { $mysqli->query('UPDATE `users` SET `verify`="2" WHERE `id`="'.$id.'"'); }
$vr = '<button class="btn blue fa fa-check" type="veri" id="veri" name="verif"> Верифицировать</button>';
}
if (isset($_POST['update'])) {
if (isset($_POST['admin']) && isset($_POST['money']) && isset($_POST['nameUp']) && isset($_POST['lastUp']) && isset($_POST['phUp'])) {
$nameUp = htmlspecialchars($_POST['nameUp']);
$lastUp = htmlspecialchars($_POST['lastUp']);
$phUp = htmlspecialchars($_POST['phUp']);
$admin = htmlspecialchars($_POST['admin']);
$money = htmlspecialchars($_POST['money']);
echo '<div class="col-md-12"><div class="alert alert-info alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>Данные успешно изменены</div></div>';
$mysqli->query('UPDATE `users` SET `first_name`="'.$nameUp.'", `last_name`="'.$lastUp.'", `photo`="'.$phUp.'", `admin`="'.$admin.'",`money`="'.$money.'" WHERE `id`="'.$id.'"'); } } ?>
<form method="post" class="form-horizontal">
<div class='col-md-12'>
<div class="portlet box">
<div class="portlet-body">
<div class="form-group">
<label class="col-md-3 control-label" for="title">Имя</label>
<div class="col-md-5">
<input type="text" class="form-control" name="nameUp" value="<? echo $fname; ?>"></div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="title">Фамилия</label>
<div class="col-md-5">
<input type="text" class="form-control" name="lastUp" value="<? echo $lname; ?>"></div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="title">Изображение</label>
<div class="col-md-5">
<input type="text" class="form-control" name="phUp" value="<? echo $ph; ?>"></div>
</div>
<div class="form-group">
<label class="col-md-3 control-label" for="title">Статус Аккаунта</label>
<div class="col-md-5">
<select class="form-control" name="admin">
<? echo $a; ?></select></div>
</div><div class="form-group">
<label class="col-md-3 control-label" for="title">Баланс</label>
<div class="col-md-5">
<input type="text" class="form-control" name="money" value="<? echo $mn; ?>"></div>
</div>
<div class="margiv-top-10">
<button class="btn green" type="update" id="update" name="update">Сохранить</button>
<? echo $vr ?> <? echo $hd ?> <? echo $bn ?> </div></div></div></div></div></div></div></form> <? } ?>






<? if(isset($_GET['ipTable'])){ ?>
<div class="col-md-6"><div class="portlet box green"><div class="portlet-title"><div class="caption">
<i class="fa fa-ban font-green"></i>
<span class="caption">IP Адреса</span>
</div></div><div class="portlet-body"><div class="table-scrollable"><table class="table table-hover"><thead><tr><th> # </th><th> IP User </th><th> Забанен </th>
</tr></thead><tbody>
<? $kek = $mysqli->query('SELECT * FROM `ip_users` ORDER BY `id` DESC');
while($get = $kek->fetch_array()){
$id = $get['id'];
$ip = $get['ip'];
$ban = $get['ban'];
if($ban == '1'){ $ban = 'Нет'; } else { $ban = 'Да'; }
echo '<tr><td> '.$id.' </td><td> '.$ip.' </td><td> '.$ban.' </td></tr>'; } ?></tbody></table></div></div></div></div><? } ?>

<? if(isset($_GET['status'])){ ?>
<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if (isset($_POST['link']) && isset($_POST['comment']) && isset($_POST['image'])) {
$url = htmlspecialchars($_POST['link']);
$com = htmlspecialchars($_POST['comment']);
$foto = htmlspecialchars($_POST['image']);
echo '<div class="note note-info">Статус добавлен</div>';
$mysqli->query('INSERT INTO `stats` (`id`, `image`, `comment`, `link`) VALUES("", "'.$foto.'", "'.$com.'", "'.$url.'")');
mysql_query($mysqli) or die(mysql_error());
}
?>
<div class="col-md-12">
<form method="post">
<div class="col-md-12"><div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="icon-bar-chart font-dark hide"></i><span class="caption-subject font-dark uppercase">Добавление Статуса</span></div></div>
<div class="portlet-body">

<div class="form-body">
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Коментарий</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="comment" id="comment">
<div class="form-control-focus"> </div>
<span class="help-block">Добавьте коментарий</span></div></div>
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Фотография</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="image" id="image">
<div class="form-control-focus"> </div></div></div>
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Ссылка на скачивание</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="link" id="link">
<div class="form-control-focus"> </div></div></div></div>
<div class="form-actions"><div class="row">
<div class="col-md-offset-3 col-md-9">
<br>
<button class="btn btn-minw btn-square btn-primary" type="add" id="submit" name="submit">Добавить</button>
</div></div></div></div></div></div></form></div>
 

<?php
function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
}?>
<? } ?>

<? if(isset($_GET['script'])){ ?>
<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if (isset($_POST['link']) && isset($_POST['comment']) && isset($_POST['image'])) {
$url = htmlspecialchars($_POST['link']);
$com = htmlspecialchars($_POST['comment']);
$foto = htmlspecialchars($_POST['image']);
echo '<div class="note note-info">Скрипт добавлен</div>';
$mysqli->query('INSERT INTO `script` (`id`, `image`, `comment`, `link`) VALUES("", "'.$foto.'", "'.$com.'", "'.$url.'")');
mysql_query($mysqli) or die(mysql_error());
}
?>
<div class="col-md-12">
<form method="post">
<div class="col-md-12"><div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="icon-bar-chart font-dark hide"></i><span class="caption-subject font-dark uppercase">Добавление Скрипта</span></div></div>
<div class="portlet-body">

<div class="form-body">
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Коментарий</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="comment" id="comment">
<div class="form-control-focus"> </div>
<span class="help-block">Добавьте коментарий</span></div></div>
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Фотография</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="image" id="image">
<div class="form-control-focus"> </div></div></div>
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Ссылка на скачивание</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="link" id="link">
<div class="form-control-focus"> </div></div></div></div>
<div class="form-actions"><div class="row">
<div class="col-md-offset-3 col-md-9">
<br>
<button class="btn btn-minw btn-square btn-primary" type="add" id="submit" name="submit">Добавить</button>
</div></div></div></div></div></div></form></div>
 

<?php
function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
}?>

<? } ?>

<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>