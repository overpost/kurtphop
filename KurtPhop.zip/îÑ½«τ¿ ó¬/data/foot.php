﻿</div></div></div></div><div class="page-footer"><div class="page-footer-inner">KurtPhop.PW @ 2017</div>
</span><div class="scroll-to-top" style="display: none;"><i class="icon-arrow-up"></i></div></div>
<script src="/resources/js/jquery-latest.js"></script>
<script src="/resources/js/app.min.js"></script>
<script src="/resources/js/function.js"></script>
<script src="/resources/js/jquery.min.js" type="text/javascript"></script>
<script src="/resources/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/resources/js/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="/resources/js/emoji.js" type="text/javascript"></script>
<script src="/resources/js/layout.js" type="text/javascript"></script>
</body><?/* GG CloudFlare */?></html>