﻿<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if(isset($_SESSION['uid'])){
$prof = $_SESSION['uid'];
$set_name = htmlspecialchars($_POST['set_name']);
$set_fam = htmlspecialchars($_POST['set_fam']);
$img_ava = htmlspecialchars($_POST['img_ava']);
echo '<div class="alert alert-info alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>Ваши данные изменены</div>';
$sql = $mysqli->query('UPDATE `users` SET `first_name`="'.$set_name.'", `last_name`="'.$set_fam.'", `photo`="'.$img_ava.'" WHERE `profile`="'.$prof.'"'); }