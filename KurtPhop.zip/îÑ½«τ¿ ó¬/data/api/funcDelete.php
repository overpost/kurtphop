﻿<? session_start();
     include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
		 $sid = $_SESSION['uid'];
		 $result = $mysqli->query('SELECT * FROM `set_func` WHERE `user_id`="'.$sid.'"');
	 if(mysqli_num_rows($result) == 0) {
	 echo 'Ты шутишь?'; } else {
	 $mysqli->query('DELETE FROM `set_func` WHERE `user_id`="'.$sid.'"');
	 echo '<li class="list-group-item bg-red">Функции удалены :)</li>'; }