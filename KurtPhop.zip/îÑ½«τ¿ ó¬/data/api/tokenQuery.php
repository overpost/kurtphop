﻿<?php  $token = htmlspecialchars($_POST['token']);

	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$token);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Токен валидный</li></ul></div>'; }else{
	 echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Токен невалидный</li></ul></div>'; }
		function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response; }