<?php
try {
$mysqli = new mysqli('localhost', 'w91356q6_1', 'overpost1337', 'w91356q6_1');
$mysqli->query('SET NAMES utf8');

if($mysqli->connect_errno) {
throw new mysqli_sql_exception("<br />Ошибка подключения: ".$mysqli->connect_errno." | ". $mysqli->connect_error); 
}
 }
catch(mysqli_sql_exception $e) {
echo $e->getMessage();
exit(); }