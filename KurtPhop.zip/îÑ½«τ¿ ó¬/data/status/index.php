<? include($_SERVER['DOCUMENT_ROOT'].'/data/head.php'); ?>
<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if (isset($_POST['link']) && isset($_POST['comment']) && isset($_POST['image'])) {
$url = htmlspecialchars($_POST['link']);
$com = htmlspecialchars($_POST['comment']);
$foto = htmlspecialchars($_POST['image']);
echo '<div class="note note-info">Статус добавлен</div>';
$mysqli->query('INSERT INTO `stats` (`id`, `image`, `comment`, `link`) VALUES("", "'.$foto.'", "'.$com.'", "'.$url.'")');
mysql_query($mysqli) or die(mysql_error());
}
?>
<div class="col-md-12">
<form method="post">
<div class="col-md-12"><div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="icon-bar-chart font-dark hide"></i><span class="caption-subject font-dark uppercase">Добавление Статуса</span></div></div>
<div class="portlet-body">

<div class="form-body">
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Коментарий</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="comment" id="comment">
<div class="form-control-focus"> </div>
<span class="help-block">Добавьте коментарий</span></div></div>
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Фотография</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="image" id="image">
<div class="form-control-focus"> </div></div></div>
<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Ссылка на скачивание</label>
<div class="col-md-9">
<input type="text" class="form-control" placeholder="" name="link" id="link">
<div class="form-control-focus"> </div></div></div></div>
<div class="form-actions"><div class="row">
<div class="col-md-offset-3 col-md-9">
<br>
<button class="btn btn-minw btn-square btn-primary" type="add" id="submit" name="submit">Добавить</button>
</div></div></div></div></div></div></form></div>
 

<?
function curl($url){
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
}?>

 <?
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>