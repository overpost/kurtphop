﻿<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/banSystem.php');

/* Дизайн сайта */
$site = $mysqli->query('SELECT `theme` FROM `site`')->fetch_array();
if($site['theme'] == '1'){ $theme = 'darkblue.css'; }
if($site['theme'] == '2'){ $theme = 'default.css'; }
if($site['theme'] == '3'){ $theme = 'blue.css'; }
if($site['theme'] == '4'){ $theme = 'grey.css'; }
if($site['theme'] == '5'){ $theme = 'light.css'; }
if($site['theme'] == '6'){ $theme = 'light2.css'; }

/* Система онлайна */
$tstamp = date('Y-m-d H:i:s');
if (isset($_SESSION['uid'])) { $sql = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) { $id = $row['id']; $uid = $_SESSION['uid']; }}
if (isset($_SESSION['uid'])) { $mysqli->query('UPDATE `users` SET `online`="2", `lastjoin`="'.$tstamp.'" WHERE `id`="'.$id.'"'); }else {}
$timeD = date('Y-m-d H:i:s', time() - 60 * 5);
$select = $mysqli->query("SELECT * FROM `users`");
while($db = $select->fetch_array()) { $lastjoin = $db['lastjoin'];
if($lastjoin < $timeD){ $mysqli->query("UPDATE `users` SET `online`='1' WHERE `lastjoin` < '$timeD'"); }
if($lastjoin > $timeD){ $mysqli->query("UPDATE `users` SET `online`='2' WHERE `lastjoin` > '$timeD'"); }
} ?>

<?php
$info = sys_getloadavg();
$нагрузка = $info[0];
if($нагрузка > 50) { die('Пошел нахуй не еби мозги'); }
?>
<!DOCTYPE html>
<html><head>
<style>
::-moz-selection { /* Code for Firefox */
    color: white;
    background: red;
}

::selection {
    color: white;
    background: red;
}
</style>
<script>
window.location.href="#          Расскажи друзьям про сайт :3"
</script>
<meta charset="utf-8"/>
<meta content="width=device-width,user-scalable=no, initial-scale=0.7" name="viewport" />
<title><? echo "$title"; ?></title>
<link rel="shortcut icon" href="/resources/img_site/favicon.png">
<meta property="og:url" content="http://<?php echo $_SERVER["SERVER_NAME"]; ?>/">
<meta property="og:site_name" content="<?php echo $_SERVER["SERVER_NAME"]; ?>">
<meta property="og:title" content="<?php echo $_SERVER["SERVER_NAME"]; ?> - Всё для ВКонтакте">
<meta name="description" content="Привет! Это сайт мелочей для Вконтакте. Здесь можно установить авто-статус и использовать API VK, а так же скачать PHP скрипты.">
<meta name="keywords" content="Скрипты для ВКонтакте, Авто-статус ВК, WALLBOT для вконтакте,статусы для вконтакте,бот для вконтакте,скрипты для вк,меняющиеся статусы вк, настенные бот вк,скрипт для очистки стены вконтакте,скрипты автостатусов вконтакте,php скрипты для вконтакте,API сервисы вконтакте,автоустановка автостатуса вконтакте,как сделать авто-статус вконтакте,php скрипты для вконтакте.">
<meta name="theme-color" content="#1f1f1f">
<meta name="CatCut7b94d7b0b5" content="DCB8C10213FBA64F009195B613B3F8A2Y5134" />
<link href="/resources/css/opes_sans.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">
<link href="/resources/css/font-awesome/emoji.css" rel="stylesheet" type="text/css"/>
<link href="/resources/css/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
<link href="/resources/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="/resources/css/components.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="/resources/css/components.min.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="/resources/css/custom.min.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="/resources/css/layout.css" rel="stylesheet" type="text/css"/>
<link href="/resources/themes/<? echo $theme; ?>" rel="stylesheet" type="text/css" id="style_color" />
<script src="/resources/js/jquery(2.1.3).js"></script>
<script src="/resources/js/emoji.js"></script>
<link href="http://qwexe.96.lt/new/css/jumbotron-narrow.css" rel="stylesheet" media="screen">
</head>
</head><body class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo page-container-bg-solid"><div class="page-header navbar navbar-fixed-top">
<div class="page-header-inner"><div class="page-logo"><a href="/"><img src="/resources/img_site/LogoSi.PNG" alt="logo" class="logo-default"></a><div class="menu-toggler sidebar-toggler"></div></div>
<? session_start();
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT `admin` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) { $admin = $row['admin']; } } if($admin == 2){ ?>
<div class="hor-menu hidden-xs hidden-sm"><ul class="nav navbar-nav">
<li class="mega-menu mega-menu-full hover-initialized" data-hover="megamenu" data-close-others="true">
<a href="/data/admin.php?system" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Система</a>
</li>
<li class="mega-menu mega-menu-full hover-initialized" data-hover="megamenu" data-close-others="true">
<a href="/data/admin.php?status" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Статусы</a>
</li>
<li class="mega-menu mega-menu-full hover-initialized" data-hover="megamenu" data-close-others="true">
<a href="/data/admin.php?script" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Скрипты</a>
</li>
<li class="mega-menu mega-menu-full hover-initialized" data-hover="megamenu" data-close-others="true">
<a href="/data/admin.php?users" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Пользователи</a>
</li>
</ul>
</div>
<? }else{ } ?>
<div class="hor-menu hor-menu-light hidden-xs">
</div>
<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"></a>
<? session_start();
if (isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) {
$first_name = $row['first_name'];
$last_name = $row['last_name'];
$photo = $row['photo'];
$profile = $row['profile'];
$money = $row['money'];
$ban = $row['ban'];
$globalId = $row['id'];
} $notices1 = $mysqli->query("SELECT COUNT(*) as count FROM `notices` WHERE id_user = '".$id."'");
if(mysqli_num_rows($notices1) == 0) {
$numtip = '0'; }else{
while($countNote = $notices1->fetch_array()) {
$numtip = $countNote['0']; } } ?>
<div class="top-menu">
<ul class="nav navbar-nav pull-right"><li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"><i class="icon-bell"></i>
<span class="badge badge-default"> <? echo $numtip; ?> </span></a><ul class="dropdown-menu"><li class="external"><h3>Уведомления</h3></li><li>
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 250px;"><ul class="dropdown-menu-list scroller" style="height: 250px; overflow: hidden; width: auto;" data-handle-color="#637283" data-initialized="1"><li>
<? $notices = $mysqli->query("SELECT * FROM notices WHERE id_user = '".$id."' ORDER BY `id` DESC");
if(mysqli_num_rows($notices) == 0) {
echo '
<a href="javascript:;"><span class="details">
<span class="label label-sm label-icon label-info"><i class="fa fa-check-circle"></i></span>Уведомлений нет</span>
</a>'; 
}else { while($go321 = $notices->fetch_array())
echo '
<a href="javascript:;">
<span class="details">
<span class="label label-sm label-icon '.$go321['color'].'">
<i class="'.$go321['type'].'"></i>
</span> '.$go321['note'].' </span>
</a>'; }
?>
</li></ul>
<div class="slimScrollBar" style="width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 121.359px; background: rgb(99, 114, 131);"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; opacity: 0.2; z-index: 90; right: 1px; background: rgb(234, 234, 234);"></div></div></li></ul></li>
<li class="dropdown dropdown-user"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"><img alt="" class="img-circle" src="<? echo "$photo"; ?>"><span class="username"> <?php echo "$first_name $last_name"; ?> </span>
<i class="fa fa-angle-down"></i></a><ul class="dropdown-menu dropdown-menu-default"><li><a href="/id<? echo "$id"; ?>"><i class="icon-user"></i> Профиль </a></li><li><a href="/pages/wallet.php"><i class="icon-wallet"></i> Магазин
<span class="badge badge-danger"> <? echo "$money"; ?> </span></a></li><li>
<li><a href="https://vk.com/id<? echo "$profile";?>"><i class="fa fa-vk"></i> Вконтакте </a></li>
<li class="divider"> </li><? if($admin == 2){ ?> <li><a href="/data/admin"><i class="fa fa-code"></i> Админка </a></li> <? } ?> <li><a href="/act?logout"><i class="icon-logout"></i> Выход </a></li></ul></li></ul></div><? } else { ?>
<div class="top-menu">
<ul class="nav navbar-nav pull-right">
<ul class="nav navbar-nav"><div style="margin-top: 4%;" class="btn-group"><div>

<script src="//ulogin.ru/js/ulogin.js"></script>
<div id="uLogin" data-ulogin="display=buttons;fields=first_name,last_name,photo_big;providers=vkontakte;redirect_uri=http%3A%2F%2F<?php echo $_SERVER["SERVER_NAME"]; ?>%2Fdata%2Fauth.php"> 
<li> <a title="" data-uloginbutton="vkontakte"> <button type="button" class="btn blue btn circle"><i class="fa fa-vk"></i> Авторизация</button></a></li></div>


</div></div></ul></ul>
</div><? } ?></div></div><div class="clearfix"></div><div class="page-container"><div class="page-sidebar-wrapper"><div class="page-sidebar navbar-collapse collapse"><ul class="page-sidebar-menu page-sidebar-menu-light" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200"><li class="heading">
<h3 class="uppercase">Меню</h3></li>
<li class="active animated fadeIn waves-effect"><a href="/"> <i class="fa fa-tv"></i><span class="title">Главная</span><span class=" title"></span></a></li>
<li class=""><a href="/pages/help.php"><i class="fa fa-question"></i><span class="title">Помощь</span><span class=""></span></a></li>
<li class=""><a href="/pages/red.php"><i class="fa fa-money"></i><span class="title">Помощь проекту</span><span class="badge badge-danger">NEW</span></a></li>
<li class=""><a href="/pages/dell.php"><i class="fa fa-diamond"></i><span class="title">Токены</span><span class="badge badge-danger">NEW</span></a></li>
<li class="start"><a href="/pages/api_vk.php" class="  "><i class="fa fa-vk"></i><span class="title ">API Вконтакте </span><span class=""></span></a></li>
<li class="nav-item"><a href="javascript:;" class="nav-link nav-toggle"><i class="fa fa-diamond"></i><span class="title">Установка</span><span class="arrow"></span></a>
<ul class="sub-menu" style="display: none;">
<li><a href="/autoSet/avtostatus"><i class="fa fa-code"></i> Авто-Статус</a></li>
<li><a href="/autoSet/avtostatus_group"><i class="fa fa-code"></i> Авто-Статус в группу </a></li>
<!--<li><a href="/autoSet/liker"><i class="fa fa-heart"></i> Лайкер <span class="badge badge-danger">NEW</span></a></li>-->
<li><a href="/autoSet/online"><i class="fa fa-code"></i> Вечный онлайн</a></li>
<li><a href="/autoSet/func"><i class="fa fa-code"></i> Функции</a></li></ul></li>
<li class="nav-item"><a href="javascript:;" class="nav-link nav-toggle waves-effect"><i class="fa fa-code"></i>
<span class="title">Cкрипты</span><span class="arrow"></span></a><ul class="sub-menu" style="display: none;">
<li><a href="/files?stats"><i class="fa fa-file-code-o"></i> Статусы</a></li>
<li><a href="/files?scripts"><i class="fa fa-file-code-o"></i> Прочие</a></li></ul></li>
<br>
<li class="waves-effect"><a class=""><i class="fa fa-battery-quarter"></i><span class="title "> Нагрузка: <? echo "$нагрузка";?> </span><span class=""></span></a></li>
<li class="waves-effect"><a class=""><i class="fa fa-code-fork"></i><span class="title"> PHP Версия: 7.0.15</span></a></li>
</ul></div></div>
<?
$kek = rand(1, 3);
if($kek == 1){
	$fraza = 'Главный создатель: vk.com/mr.kurtphop';
} elseif ($kek == 2){
	$fraza = 'Если вы обнаружили ошибку пишите в Тех.Поддержку в разделе "Помощь"';
} elseif ($kek == 3) {
	$fraza = 'Главный создатель: vk.com/mr.kurtphop';
}

?>
<div class="page-content-wrapper"><div class="page-content"><div class="page-bar"><ul class="page-breadcrumb"><li><? echo $fraza; ?></li></ul>
<div class="page-toolbar">
<div id="dashboard-report-range" class="pull-right tooltips btn btn-sm waves-effect" data-original-title="" title=""><i class="icon-calendar"></i><span class="thin"> &nbsp;<script src="/resources/js/time.js" type="text/javascript"></script></span>
</div></div>
</div>
<div class="row"><br>