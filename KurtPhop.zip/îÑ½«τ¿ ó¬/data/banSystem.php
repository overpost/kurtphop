<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$aacMode = $mysqli->query('SELECT `AAC` from `site`');
$fetchAAC = $aacMode->fetch_array();
$aacTurned = $fetchAAC['AAC'];

function getRealIpAddr() {
if (!empty($_SERVER['HTTP_CLIENT_IP']))
{ $ip=$_SERVER['HTTP_CLIENT_IP']; }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
{ $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; }
else { $ip=$_SERVER['REMOTE_ADDR']; } return $ip; }
if (strstr($_SERVER['HTTP_USER_AGENT'], 'YandexBot')) {$bot='YandexBot';}
elseif (strstr($_SERVER['HTTP_USER_AGENT'], 'Googlebot')) {$bot='Googlebot';}
else { $bot=$_SERVER['HTTP_USER_AGENT']; }
$ip = getRealIpAddr(); // IP Done

/* Для заполнения */
$text = 
'Вы заблокированы за нарушение правил сайта<br>
Админ: vk.com/id90727'; // Тут вводим текст если пользователь заблокирован
$proxy = ''; //IP Адрес заглушки
/* Функции */

if($ip == $proxy) {} else { //Проверка на заглушку
if($aacTurned == '1'){
$check = $mysqli->query("SELECT * FROM ip_users WHERE ip='$ip'");
if(mysqli_num_rows($check) == 0) { $mysqli->query('INSERT INTO `ip_users` (`ip`) VALUES("'.$ip.'")'); }
$res1 = $mysqli->query('SELECT `ban` FROM `ip_users` WHERE `ip` = "'.$ip.'"');
while($row1 = $res1->fetch_array()) { $did = $row1['ban']; } if($did > 1){ die(include($_SERVER['DOCUMENT_ROOT'].'/pages/ban.php')); }
$agent = $_SERVER['HTTP_USER_AGENT'];
if (strpos($agent,"DISCo Pump") ||
strpos($agent,"Offline Explorer") ||
strpos($agent,"Teleport") ||
strpos($agent,"WebZIP") ||
strpos($agent,"WebCopier") ||
strpos($agent,"Wget") ||
strpos($agent,"FlashGet") ||
strpos($agent,"CIS TE") ||
strpos($agent,"DTS Agent") ||
strpos($agent,"WebReaper") ||
strpos($agent,"HTTrack") ||
strpos($agent,"HideMe") ||
strpos($agent,"view-source") ||
strpos($agent,"hideme") ||
strpos($agent,"(compatible; MSIE 6.0; Windows NT 5.0)") ||
strpos($agent,"(compatible; MSIE 5.5; Windows NT 5.0)") ||
strpos($agent,"(compatible; MSIE 5.01; Windows NT 5.0)") ||
strpos($agent,"(compatible; MSIE 5.0; Win32)") ||
strpos($agent,"(compatible; MSIE 4.01; Windows 98)") ||
strpos($agent,"(compatible; MSIE 4.01; Windows 95)") ||
strpos($agent,"(compatible; MSIE 4.01; Windows NT)") ||
strpos($agent,"(Windows NT 5.0; U)") ||
strpos($agent,"(Win98; I)") ||
strpos($agent,"(Windows; U; Windows NT 5.0; en-US; rv:1.1) Gecko/20020826") ||
strpos($agent,"(Win95; I)") ||
strpos($agent,"(compatible; MSIE 3.01; Windows 95)") ||
strpos($agent,"(X11; I; Linux 2.0.34 i686)") ||
strpos($agent,"(X11; U; SunOS 5.5.1 sun4m)") ||
strpos($agent,"(Macintosh; I; PPC)") ||
strpos($agent,"(Macintosh; I; PPC)") ||
strpos($agent,"(OS/2; I)") ||
strpos($agent,"(X11; U; SunOS 5.6 sun4u)") ||
strpos($agent,"(X11; I; AIX 4.1)") ||
strpos($agent,"(X11; I; FreeBSD 2.2.6-RELEASE i386)") ||
strpos($agent,"(X11; I; IRIX 6.3 IP32)") ||
strpos($agent,"(compatible; MSIE 2.0)") ||
strpos($agent,"(compatible; MS FrontPage Express 2.0)") ||
strpos($agent,"(Win98; I)") ||
strpos($agent,"(compatible; HTTrack 3.0x; Windows 98)") ||
strpos($agent,"(offline browser; web mirror utility)") ||

strpos($agent,"Web Downloader")) {
$mysqli->query('UPDATE `ip_users` SET `ban`="2" WHERE `ip`="'.$ip.'"');
$chUser = $mysqli->query('SELECT * FROM `users` WHERE ip_user="'.$ip.'"');
if(mysqli_num_rows($chUser) == 0) {} else{ $mysqli->query('UPDATE `users` SET `ban`="2" WHERE `ip_user`="'.$ip.'"'); die('lol, нехуй рипать сайт:D'); } }
} //Активация AAC

}
$checkBan = $mysqli->query('SELECT `ban` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $checkBan->fetch_array()) { $ban = $row['ban']; } if($ban == 2){ die(include($_SERVER['DOCUMENT_ROOT'].'/pages/ban.php')); }