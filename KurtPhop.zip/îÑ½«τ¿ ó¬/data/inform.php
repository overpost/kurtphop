﻿<?php /* Функция: getRealIP */
function getRealIpAddr() {
if (!empty($_SERVER['HTTP_CLIENT_IP']))
{ $ip=$_SERVER['HTTP_CLIENT_IP']; }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
{ $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; }
else { $ip=$_SERVER['REMOTE_ADDR']; }
return $ip; }
if (strstr($_SERVER['HTTP_USER_AGENT'], 'YandexBot')) {$bot='YandexBot';}
elseif (strstr($_SERVER['HTTP_USER_AGENT'], 'Googlebot')) {$bot='Googlebot';}
else { $bot=$_SERVER['HTTP_USER_AGENT']; }
$iz = getRealIpAddr();
if($iz == '') {
	$ip = 'Proxy Mode';
} else { $ip = getRealIpAddr(); }
/* Функции: Дополнительные */
$json_kurs = file_get_contents('http://query.yahooapis.com/v1/public/yql?q=select+*+from+yahoo.finance.xchange+where+pair+=+%22USDRUB,EURRUB%22&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys&callback=');
$json_kurs = json_decode($json_kurs, true);
$usd = $json_kurs['query']['results']['rate']['0']['Rate'];
$euro = $json_kurs['query']['results']['rate']['1']['Rate'];

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$s1 = $mysqli->query("SELECT COUNT(*) as count FROM `status`");
while($db = $s1->fetch_array()) { $statusAvto = $db['0']; }
$s2 = $mysqli->query("SELECT COUNT(*) as count FROM `groupstat`");
while($db = $s2->fetch_array()) { $groupAvto = $db['0']; }
$s3 = $mysqli->query("SELECT COUNT(*) as count FROM `online`");
while($db = $s3->fetch_array()) { $onlineAvto = $db['0']; }
$s4 = $mysqli->query("SELECT COUNT(*) as count FROM `sms_bot`");
while($db = $s4->fetch_array()) { $botAvto = $db['0']; }
$s5 = $mysqli->query("SELECT COUNT(*) as count FROM `set_func`");
while($db = $s5->fetch_array()) { $funcAvto = $db['0']; }
$count = $statusAvto + $groupAvto + $onlineAvto + $botAvto + $funcAvto;
$res = $mysqli->query("SELECT COUNT(*) as count FROM `users`");
while($db = $res->fetch_array()) { $info = $db['0']; }

/* Курл ебал Карал :D */
function api($method, $parameter) { $return = curl("https://api.vk.com/method/" . $method . "?" . $parameter);
return json_decode($return, true); } function curl($url, $post = null) {
$ch = curl_init( $url );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417
Firefox/3.0.3');
if	($post) { curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response; } ?>
<div class="col-md-4">
<div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="fa fa-cog"></i><span class="caption-subject font-dark bold uppercase">Авто Установки</span></div></div>
<div class="portlet-body"><div class="form-body">
<ul class="list-group"><li class="list-group-item">Автостатус<span class="badge badge-default"><? echo $statusAvto ?></span></li>
<li class="list-group-item">Автостатус в группу<span class="badge badge-success"><? echo $groupAvto ?></span></li>
<!--<li class="list-group-item">Лайкер<span class="badge badge-black"><? echo $botAvto ?></span></li> -->
<li class="list-group-item">Вечный онлайн<span class="badge badge-danger"><? echo $onlineAvto ?></span></li>
<li class="list-group-item">Функции<span class="badge badge-info"><? echo $funcAvto ?></span></li></ul></div></div></div></div>

<div class="col-md-4">
<div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="fa fa-user"></i><span class="caption-subject font-dark bold uppercase">Состав</span></div></div>
<div class="portlet-body"><div class="form-body">
<table class="table table-light"><thead></thead><tbody>
<? $uget = curl('https://api.vk.com/method/users.get?name_case=Nom&fields=status,photo_max&uid=245410942');       
$json = json_decode($uget,2);
$ownerUid = $json['response']['0']['uid'];
$ownerName = $json['response']['0']['first_name'];
$ownerFama = $json['response']['0']['last_name'];
$ownerPhoto = $json['response']['0']['photo_max'];
echo '<tr><td class="fit"><img class="user-pic" src="'.$ownerPhoto.'"></td><td><a href="https://vk.com/id'.$ownerUid.'" class="primary-link">'.$ownerName.' '.$ownerFama.'</a></td><td>Создатель</td></tr>'; 
$mm = array(1 => 'Января', 2 => 'Февраля', 3 => 'Марта', 4 => 'Апреля', 5 => 'Мая', 6 => 'Июня', 7 => 'Июля', 8 => 'Августа', 9 => 'Сентября', 10 => 'Октября', 11 => 'Ноября', 12 => 'Декабря'); 
$set_date = date("d.m.y"); ?>
									<script type="text/javascript">
function clock() {
var d = new Date();
var month_num = d.getMonth()
var day = d.getDate();
var hours = d.getHours();
var minutes = d.getMinutes();
var seconds = d.getSeconds();

month=new Array("января", "февраля", "марта", "апреля", "мая", "июня",
"июля", "августа", "сентября", "октября", "ноября", "декабря");

if (day <= 9) day = "0" + day;
if (hours <= 9) hours = "0" + hours;
if (minutes <= 9) minutes = "0" + minutes;
if (seconds <= 9) seconds = "0" + seconds;
if (1337 <= 9) seconds = "0" + 1337;

date_time = "Сегодня " + day + " " + month[month_num] + " " +
" "+ hours + ":" + minutes + ":" + seconds + " "
if (document.layers) {
 document.layers.doc_time.document.write(date_time);
 document.layers.doc_time.document.close();
}
else document.getElementById("doc_time").innerHTML = date_time;
 setTimeout("clock()", 1000);
}
</script>
<tr><td class="fit"><img class="user-pic" src="https://pp.userapi.com/c637522/v637522604/41512/xulHlCZkqSE.jpg"></td><td><a href="https://vk.com/egidarov" class="primary-link">Саша Егидаров</a></td><td>Создатель Хохол/Еврей</td></tr>
<tr><td class="fit"><img class="user-pic" src="https://pp.userapi.com/c837520/v837520811/1ae5/cfCO_4bmwu4.jpg"></td><td><a href="https://vk.com/serhiy_kosovchych" class="primary-link">Сергій Косовчич</a></td><td>Скриптер и топ пацан</td></tr>
<tr><td class="fit"><img class="user-pic" src="https://pp.userapi.com/c638529/v638529382/2ac95/yR3bmNAsDaY.jpg"></td><td><a href="https://vk.com/mizaor" class="primary-link">Максимка Топовый</a></td><td>Жид Нахлебник Еврей</td></tr>
</tbody></table></div></div></div></div>
<div class="col-md-4">
<div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="fa fa-bar-chart"></i><span class="caption-subject font-dark bold uppercase">Дополнительное</span></div></div>
<div class="portlet-body"><div class="form-body">
<li class="list-group-item">Ваш IP<span class="badge badge-danger"><?php echo $ip; ?></span></li>
<li class="list-group-item">Всего установок<span class="badge badge-success"><?php echo $count; ?></span></li>
<li class="list-group-item">Юзеров<span class="badge badge-info"><?php echo "$info"; ?></span></li>
<li class="list-group-item">Доллар<span class="badge badge-warning"><? echo $usd ?></span></li>
<li class="list-group-item">Евро<span class="badge badge-success"><? echo $euro ?></span></li>
<li class="list-group-item">Uptime основного сайта<span class="badge badge-primary">100%</span></li>
<li class="list-group-item">Время загрузки сайта<span class="badge badge-default">1.176 секунд</span></li>
</div></div></div></div>
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-info font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Информация о работоспособности сервера (API функции)</span>
</div></div><div class="portlet-body"><div class="form-body">
<ul class="list-group">
<li class="list-group-item">Среднее время работы Авто Статусов<span class="badge badge-success">4.422 секунд</span></li>
<li class="list-group-item">Среднее время работы АвтоСтатуса для Группы<span class="badge badge-info">0.000 секунд</span></li>
<li class="list-group-item">Среднее время работы Функций для Профиля<span class="badge badge-info">3.096 секунд</span></li>
<li class="list-group-item">Среднее время работы Вечного Онлайна<span class="badge badge-danger">1.913 секунд</span></li>
</ul></div></div></div>