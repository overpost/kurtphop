<?
if (isset($_GET['func1']) == 'datareg') { 
$id=$_POST['id'];
if($id){
$запрос = curl('https://api.vk.com/method/users.get?lang=ru&user_ids='.$id.'&fields=photo_50');
$json = json_decode($запрос,1);
$first = $json["response"]["0"]["first_name"];
$last = $json["response"]["0"]["last_name"];
$img = $json["response"]["0"]["photo_50"];
$uid = $json["response"]["0"]["uid"];
$deactivated = $json["response"]["0"]["deactivated"];
$информация = file_get_contents('http://vk.com/foaf.php?id='.$uid);
$вырезка = '/<ya:created dc:date="([\\d]{4}-[\\d]{2}-[\\d]{2}T[\\d]{2}:[\\d]{2}:[\\d]{2}\\+[\\d]{2}:[\\d]{2})"/i';
preg_match($вырезка, $информация, $matches);
$кастрация = explode("T", $matches[1]);
$кастрация1 = explode("-", $кастрация[0]);
if($uid){
if($deactivated){
if($deactivated == 'deleted') echo '<div class="note note-danger">Страница удалена</div>';
elseif($deactivated == 'banned') echo '<div class="note note-danger">Страница заблокирована</div>';
}else echo '<div class="alert alert-info"><img src="'.$img.'" style="border-radius:1337px;float:left;margin-right:10px;"><h4>'.$first.' '.$last.'</h4><p>Страница зарегистрирована '.$кастрация1[2].'.'.$кастрация1[1].'.'.$кастрация1[0].'</p></div>';
}else echo '<div class="note note-danger">Ошибка</div>';
}}
//Нова функс 2
if (isset($_GET['func2']) == 'friend') {
$uid = $_POST['uid'];
if($uid){
$запрос = curl('https://api.vk.com/method/users.get?lang=ru&name_case=gen&user_ids='.$uid);
$json = json_decode($запрос,1);
$uid = $json["response"]["0"]["uid"];
$name = $json["response"]["0"]["first_name"].' '.$json["response"]["0"]["last_name"];
if($uid){
$запрос = curl('https://api.vk.com/method/friends.get?lang=ru&uid='.$uid);
$json = json_decode($запрос,1);
$список = $json["response"];
if($json["response"]["0"]){
echo '<div class="alert alert-success"><h4><center>Друзья <a href="//vk.com/id'.$uid.'">'.$name.'</a><br>'.count($список).' друзей<br>снизу список ID через запятую<input type="text" class="form-control" value="';
$ab = 1;
for($i = 0; $i < count($список); $i++ ) {
if($ab == $i){
$ab++;
echo ','; }
echo $json["response"][$i]; }
echo '" style="  margin: 20px 0px 20px;"></center></h4></div>'; }
else echo '<div class="note note-danger">Друзей нет</div>';
}}}
//Нова функс 3
if (isset($_GET['func3']) == 'change') {
$token = htmlspecialchars($_POST['token']);		
$text = htmlspecialchars($_POST['text']);              
$users_get = curl('https://api.vk.com/method/users.get?name_case=Nom&access_token='. $token);                  
$json = json_decode($users_get,1);
$idq = $json['response']['0']['uid'];
$запрос = curl('https://api.vk.com/method/users.get?lang=ru&user_ids='. $idq .'&fields=photo_50');
$json = json_decode($запрос,1);
$first_name = $json["response"]["0"]["first_name"];
$last_name = $json["response"]["0"]["last_name"];
$res = curl('https://api.vk.com/method/status.set?text='.urlencode($text).'&access_token='.$token);
$lo = 'response';
$pos = strripos($res, $lo);
if($pos == true){
echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-green">Капчи не обнаружено. Статус изменён на: '.$text.'</li></ul></div>';
}else{ echo '<div class="col-md-12"><ul class="list-group"><li class="list-group-item bg-red">Ваш <b>access_token</b> не рабочий или в статусе есть Капча!</li></ul></div>'; }}
if (isset($_GET['func4']) == 'rackbe') {
//Нова функс 4
$qid = $_POST['id'];
$type = "id";
$text = '<a href="http://vk.com/'.$type.bcadd($qid,'79064188910487732224').'">http://vk.com/'.$type.bcadd($qid,'79064188910487732224').'</a>';
 echo '<div class="note note-info">Длинный ид пользователя:</strong> '.replace(''.$text.'').' </div>'; }
 
//Отдельная функсия гуру
function replace($str){
$rplc = array("id"=>"id", "http://vk.com/id79064188910487732224"=>"");
return strtr($str,$rplc);
} 
//Шкаев сосёт на эти запрос с 1 по 3 функцию обработка на сайте VKDEV. Зачем ты это читаешь у тебя уже болят глаза от ашипак орфаграфии.
function api($method, $parametrs) 
{
$get = curl('https://api.vk.com/method/'.$method.'?'.$parametrs);
return json_decode($get, true); }
function curl($url){
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
$response = curl_exec( $ch );
curl_close( $ch );
return $response;
}
?>
