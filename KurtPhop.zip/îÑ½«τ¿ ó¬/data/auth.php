<? session_start();
$monthes = array(1 => 'Января', 2 => 'Февраля', 3 => 'Марта', 4 => 'Апреля', 5 => 'Мая', 6 => 'Июня', 7 => 'Июля', 8 => 'Августа', 9 => 'Сентября', 10 => 'Октября', 11 => 'Ноября', 12 => 'Декабря');
$datereg = "".date('d '.$monthes[(date('n'))].' Y')." В ".date('H:i', time() + 24 * 3600)."";
$tstamp = date('Y-m-d H:i:s');

$s = file_get_contents('https://ulogin.ru/token.php?token=' . $_POST['token'] . '&host=' . $_SERVER['HTTP_HOST']);
$user = json_decode($s, true);
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

function getRealIpAddr() {
  if (!empty($_SERVER['HTTP_CLIENT_IP']))        // Определяем IP
  { $ip=$_SERVER['HTTP_CLIENT_IP']; }
  elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))    // Если IP идёт через прокси
  { $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; }
  else { $ip=$_SERVER['REMOTE_ADDR']; }
  return $ip;
}
if (strstr($_SERVER['HTTP_USER_AGENT'], 'YandexBot')) {$bot='YandexBot';}
elseif (strstr($_SERVER['HTTP_USER_AGENT'], 'Googlebot')) {$bot='Googlebot';}
else { $bot=$_SERVER['HTTP_USER_AGENT']; }
$ip = getRealIpAddr();

if(isset($user)) {

if (isset($user['uid'])) {
	
$uid2 = $user['uid'];
$auth = $mysqli->query('SELECT * FROM `users` WHERE `profile`="'.$user['uid'].'"');
if(mysqli_num_rows($auth) == 0) {
	$_SESSION['first_name'] = $user['first_name'];
	$_SESSION['last_name'] = $user['last_name']; 
	$_SESSION['photo'] = $user['photo_big'];
	$_SESSION['uid'] = $user['uid'];
	$_SESSION['token'] = $user['access_token'];
	
    $insert = $mysqli->query('
	INSERT INTO `users` (`first_name`, `last_name`, `ip_user`, `photo`, `profile`, `datereg`, `lastjoin`)  
	VALUES("'.$user['first_name'].'", "'.$user['last_name'].'", "'.$ip.'", "'.$user['photo_big'].'", "'.$user['uid'].'", "'.$datereg.'", "'.$tstamp.'")
	');
	
	header("Location: /");
   exit();
} else {
  $_SESSION['uid'] = $user['uid'];  
  $id = $user['uid'];
	$mysqli->query('UPDATE `users` SET `lastjoin`="'.$tstamp.'", `ip_user`="'.$ip.'" WHERE `profile`="'.$user["uid"].'"');
	header("Location: /");
	exit();
} } else { 
    header("Location: /"); }
}
     function api($method, $parameter) { 
		$return = curl("https://api.vk.com/method/" . $method . "?" . $parameter);
		    return json_decode($return, true);  }
          	function curl($url, $post = null) {
		$ch = curl_init( $url );
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417
		Firefox/3.0.3');
		if	($post) {
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		$response = curl_exec( $ch );
		curl_close( $ch );
		return $response;
    }
?>