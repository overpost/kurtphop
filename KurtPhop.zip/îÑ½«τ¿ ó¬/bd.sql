-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 24 2016 г., 10:37
-- Версия сервера: 5.6.28-76.1-beget-log
-- Версия PHP: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `qwelol13_ruslan`
--

-- --------------------------------------------------------

--
-- Структура таблицы `groupstat`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `groupstat`;
CREATE TABLE `groupstat` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `ip_users`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `ip_users`;
CREATE TABLE `ip_users` (
  `id` int(1) NOT NULL,
  `ip` text CHARACTER SET utf8 NOT NULL,
  `ban` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=cp1257 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `ip_users`
--

-- --------------------------------------------------------

--
-- Структура таблицы `notices`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `notices`;
CREATE TABLE `notices` (
  `id` int(1) NOT NULL,
  `id_user` text COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `color` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `notices`
--

INSERT INTO `notices` (`id`, `id_user`, `note`, `type`, `color`) VALUES
(1, '1', 'Ура! мы открыли сайт!', 'fa fa-spin fa-cog', 'label-info');

-- --------------------------------------------------------

--
-- Структура таблицы `online`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `online`;
CREATE TABLE `online` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `script`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `script`;
CREATE TABLE `script` (
  `id` int(1) NOT NULL,
  `image` text NOT NULL,
  `comment` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `script`
--

INSERT INTO `script` (`id`, `image`, `comment`, `link`) VALUES
(1, 'https://pp.vk.me/c604319/v604319042/8d99/37E5vmXrmSU.jpg', 'Отчет', 'https://yadi.sk/d/GANO0IiGrTe9u');

-- --------------------------------------------------------

--
-- Структура таблицы `set_func`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `set_func`;
CREATE TABLE `set_func` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `friends_add` int(2) NOT NULL,
  `friends_delete` int(13) NOT NULL,
  `online` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `set_func`
--

-- --------------------------------------------------------

--
-- Структура таблицы `site`
--
-- Создание: Авг 22 2017 г., 19:38
-- Последнее обновление: Авг 23 2016 г., 17:52
--

DROP TABLE IF EXISTS `site`;
CREATE TABLE `site` (
  `id` int(1) NOT NULL,
  `Name` text NOT NULL,
  `theme` text NOT NULL,
  `AAC` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `site`
--

INSERT INTO `site` (`id`, `Name`, `theme`, `AAC`) VALUES
(1, 'KurtPhop.PW', '1', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `sms_bot`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `sms_bot`;
CREATE TABLE `sms_bot` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sms_bot`
--

-- --------------------------------------------------------

--
-- Структура таблицы `stats`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` int(1) NOT NULL,
  `image` text NOT NULL,
  `comment` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `stats`
--

INSERT INTO `stats` (`id`, `image`, `comment`, `link`) VALUES
(1, 'https://pp.vk.me/c630226/v630226074/4fdfe/4HnpHBb8wW4.jpg', 'АвтоСтатус', 'https://yadi.sk/d/c6m3gaP1uQS8A');

-- --------------------------------------------------------

--
-- Структура таблицы `status`
--
-- Создание: Авг 22 2016 г., 19:39
-- Последнее обновление: Авг 23 2016 г., 05:50
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int(1) NOT NULL,
  `user_id` int(1) NOT NULL,
  `token` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `city` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status_id` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `status`
--


-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Авг 22 2017 г., 19:38
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(1) NOT NULL,
  `first_name` text CHARACTER SET utf8 NOT NULL,
  `last_name` text CHARACTER SET utf8 NOT NULL,
  `photo` text COLLATE utf8_unicode_ci NOT NULL,
  `ip_user` text CHARACTER SET utf8 NOT NULL,
  `profile` text COLLATE utf8_unicode_ci NOT NULL,
  `ban` int(1) NOT NULL DEFAULT '1',
  `admin` int(1) NOT NULL DEFAULT '1',
  `datereg` text CHARACTER SET utf8 NOT NULL,
  `online` int(1) NOT NULL DEFAULT '2',
  `lastjoin` text CHARACTER SET utf8 NOT NULL,
  `money` int(1) NOT NULL DEFAULT '40',
  `hidden` int(1) NOT NULL DEFAULT '1',
  `verify` int(1) NOT NULL DEFAULT '1',
  `slg` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Индексы таблицы `groupstat`
--
ALTER TABLE `groupstat`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `ip_users`
--
ALTER TABLE `ip_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Индексы таблицы `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `script`
--
ALTER TABLE `script`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `set_func`
--
ALTER TABLE `set_func`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `site`
--
ALTER TABLE `site`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `site` ADD FULLTEXT KEY `Name` (`Name`);

--
-- Индексы таблицы `sms_bot`
--
ALTER TABLE `sms_bot`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `groupstat`
--
ALTER TABLE `groupstat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `ip_users`
--
ALTER TABLE `ip_users`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `online`
--
ALTER TABLE `online`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `script`
--
ALTER TABLE `script`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `set_func`
--
ALTER TABLE `set_func`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `site`
--
ALTER TABLE `site`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `sms_bot`
--
ALTER TABLE `sms_bot`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `stats`
--
ALTER TABLE `stats`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `status`
--
ALTER TABLE `status`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
